#!/usr/bin/env python3
"""CRA v1.1 finite reference interpreter, qualifier, and carrier builder.

The JSON source defines the architecture. This script validates its internal graph,
executes bounded reference profiles, checks hostile vectors, renders the human
projection, and builds the exact six-member AI packet. Verification uses only the
Python standard library; DOCX rendering additionally requires python-docx.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import re
import shutil
import sys
import tempfile
import unicodedata
import zipfile
from collections import Counter, defaultdict, deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable


VERSION = "1.1"
SOURCE_REL = Path("references/cra.json")
LEXICON_REL = Path("references/structural_lexicon.json")
VECTORS_REL = Path("tests/vectors.jsonl")
SKILL_REL = Path("SKILL.md")
SCRIPT_REL = Path("scripts/cra.py")
MANIFEST_REL = Path("MANIFEST.json")
PACKET_ALLOWLIST = (SKILL_REL, SOURCE_REL, LEXICON_REL, SCRIPT_REL, VECTORS_REL, MANIFEST_REL)
# Preserve the v1 canonical data domain so previously valid v1 records remain
# interoperable; v1.1-only certificates use distinct digest labels.
DOMAIN = b"CRA/1.0\0"


class CRAError(RuntimeError):
    pass


def normalize(value: Any) -> Any:
    if value is None or isinstance(value, bool):
        return value
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        raise CRAError("binary floating-point values are not canonical")
    if isinstance(value, str):
        return unicodedata.normalize("NFC", value)
    if isinstance(value, list):
        return [normalize(item) for item in value]
    if isinstance(value, dict):
        result: dict[str, Any] = {}
        for key, item in value.items():
            if not isinstance(key, str):
                raise CRAError("all object keys must be strings")
            key = unicodedata.normalize("NFC", key)
            if key in result:
                raise CRAError(f"duplicate key after NFC normalization: {key}")
            result[key] = normalize(item)
        return result
    raise CRAError(f"unsupported canonical value: {type(value).__name__}")


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(
        normalize(value), ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")


def digest_bytes(payload: bytes, label: str = "") -> str:
    return hashlib.sha256(DOMAIN + label.encode("utf-8") + b"\0" + payload).hexdigest()


def digest_object(value: Any, label: str) -> str:
    return digest_bytes(canonical_bytes(value), label)


def raw_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _unique_json_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for raw_key, value in pairs:
        key = unicodedata.normalize("NFC", raw_key)
        if key in result:
            raise CRAError(f"duplicate JSON member after NFC normalization: {key}")
        result[key] = value
    return result


def _reject_json_constant(value: str) -> None:
    raise CRAError(f"noncanonical JSON constant: {value}")


def strict_json_loads(text: str) -> Any:
    try:
        parsed = json.loads(
            text,
            object_pairs_hook=_unique_json_object,
            parse_constant=_reject_json_constant,
        )
    except json.JSONDecodeError as exc:
        raise CRAError(f"invalid JSON: {exc}") from exc
    return normalize(parsed)


def read_json(path: Path) -> Any:
    return strict_json_loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def root_from_arg(value: str | None) -> Path:
    if value:
        root = Path(value).resolve()
    else:
        root = Path(__file__).resolve().parents[1]
    if not (root / SOURCE_REL).is_file():
        raise CRAError(f"CRA root lacks {SOURCE_REL}: {root}")
    return root


def walk_dicts(value: Any) -> Iterable[dict[str, Any]]:
    if isinstance(value, dict):
        yield value
        for item in value.values():
            yield from walk_dicts(item)
    elif isinstance(value, list):
        for item in value:
            yield from walk_dicts(item)


def source_index(source: dict[str, Any]) -> dict[str, dict[str, Any]]:
    index: dict[str, dict[str, Any]] = {}
    duplicates: list[str] = []
    for item in walk_dicts(source):
        item_id = item.get("id")
        if isinstance(item_id, str):
            if item_id in index:
                duplicates.append(item_id)
            index[item_id] = item
    if duplicates:
        raise CRAError(f"duplicate source IDs: {sorted(set(duplicates))}")
    return index


RESOURCE_RULES = {"REUSABLE", "AFFINE", "LINEAR", "NONTRANSFERABLE", "ATTENUATING"}
REGIME_CAPABILITIES = {"CONTEXTUALIZE", "JUDGE", "APPLY", "ADMIT", "COMPOSE", "REASSESS"}
JUDGMENT_VERIFIER = "finite-satisfaction-v1"
ADMISSION_VERIFIER = "admit-supported-v1"
CLOSURE_VERIFIER = "finite-closure-v1"
CORRESPONDENCE_VERIFIER = "finite-correspondence-v1"
INSTANCE_VERIFIER = "finite-correspondence-instance-v1"
INTRODUCTION_VERIFIER = "finite-introduction-v1"
COPY_VERIFIER = "finite-copy-v1.1"
SPLIT_VERIFIER = "finite-split-v1.1"
MERGE_VERIFIER = "finite-merge-v1.1"
V02_ROOT_IDS = {
    "Context", "Status", "Candidate", "Crossing", "Account", "Evaluation",
    "Resolution", "Commit", "Rebinding",
}
V02_LAW_IDS = {f"CRA-v0.2-L{index:02d}" for index in range(1, 21)}
V02_PROFILE_IDS = {
    "FORMATION", "TRANSFORMATION", "TRANSLATION", "PROJECTION", "COMPRESSION",
    "TRANSFER", "COMPOSITION", "ACTION", "SUCCESSION", "MIGRATION", "ROLLBACK",
    "AUTONOMOUS_UPDATE",
}
V02_FRONTIER_IDS = {f"CRA-F{index:02d}" for index in range(1, 7)}
COMPOSITION_VERIFIER = "finite-compose-v1"
CROSSING_FIELDS = {
    "id", "correspondence_ref", "constructor_ref", "source_basis_refs", "source_membrane",
    "destination_basis_ref", "produced_targets", "account_edges", "dependencies", "validity",
    "loss", "error", "residual",
}


def valid_regime_shape(regime: Any) -> bool:
    """Return whether a Regime exposes the complete executable finite interface."""
    if not isinstance(regime, dict):
        return False
    return (
        isinstance(regime.get("id"), str)
        and bool(regime.get("id"))
        and isinstance(regime.get("version"), str)
        and bool(regime.get("version"))
        and string_list(regime.get("sentences"), unique=True)
        and string_list(regime.get("models"), unique=True)
        and isinstance(regime.get("satisfaction"), dict)
        and isinstance(regime.get("ports"), dict)
        and bool(regime.get("ports"))
        and isinstance(regime.get("resource_laws"), dict)
        and bool(regime.get("resource_laws"))
        and string_list(regime.get("verifier_interfaces"), unique=True)
        and isinstance(regime.get("policy_interfaces"), dict)
        and string_list(regime.get("trusted_roots"), unique=True)
        and regime.get("wf_interface") == "finite-set-v1"
        and regime.get("dependency_interface") == CLOSURE_VERIFIER
        and isinstance(regime.get("judgment_interfaces"), dict)
        and isinstance(regime.get("admission_interfaces"), dict)
        and string_list(regime.get("equivalence_interfaces"), unique=True)
        and string_list(regime.get("constructor_interfaces"), unique=True)
        and string_list(regime.get("capabilities"), unique=True)
        and set(regime.get("capabilities", [])) <= REGIME_CAPABILITIES
    )


def executable_regime_shape(regime: dict[str, Any]) -> bool:
    """Check the finite tables and every named built-in interface."""
    policy_interfaces = regime.get("policy_interfaces", {})
    return (
        set(regime.get("satisfaction", {})) == set(regime.get("models", []))
        and all(
            string_list(value, unique=True)
            and set(value) <= set(regime.get("sentences", []))
            for value in regime.get("satisfaction", {}).values()
        )
        and all(
            isinstance(port, dict)
            and set(port) == {"type"}
            and isinstance(port.get("type"), str)
            and bool(port.get("type"))
            for port in regime.get("ports", {}).values()
        )
        and all(rule in RESOURCE_RULES for rule in regime.get("resource_laws", {}).values())
        and regime.get("judgment_interfaces") == {"FINITE_SATISFACTION": JUDGMENT_VERIFIER}
        and set(regime.get("admission_interfaces", {})) <= {"ADMIT_SUPPORTED"}
        and all(value == ADMISSION_VERIFIER for value in regime.get("admission_interfaces", {}).values())
        and all(
            isinstance(spec, dict)
            and set(spec) == {"version", "rule", "verifier"}
            and isinstance(spec.get("version"), str)
            and bool(spec.get("version"))
            and spec.get("rule") in regime.get("admission_interfaces", {})
            and spec.get("verifier") == regime.get("admission_interfaces", {}).get(spec.get("rule"))
            for spec in policy_interfaces.values()
        )
        and set(regime.get("equivalence_interfaces", [])) <= {"casefold-text-v1", "all-leaves-v1"}
        and set(regime.get("constructor_interfaces", [])) <= {INTRODUCTION_VERIFIER}
    )


def validate_succession_contract(lineage: Any) -> dict[str, Any]:
    """Execute the finite v0.2→v1.1 disposition and frontier-conservation contract."""
    if not isinstance(lineage, dict):
        raise CRAError("lineage contract is absent")
    account = lineage.get("succession_account")
    if not isinstance(account, dict) or account.get("schema") != "cra.succession/1.1":
        raise CRAError("v0.2→v1.1 succession account is absent or untyped")
    predecessor = account.get("predecessor", {})
    if (
        predecessor.get("release") != "CRA v0.2"
        or predecessor.get("architecture_fingerprint") != "8542a046d3598a96403971dfa2d85cbf7856eca67c6ef82ee62c5dcccdbdceac"
        or predecessor.get("schema_fingerprint") != "4e5bbd6a6e64880cf69a6733ea41d778f9d84198743ec7a61b7696ae3f07355f"
        or predecessor.get("schema_sha256") != "a2287f0755273d5627ffd045439f434fa95ef4864bf8f438bdd414bf78d18cfb"
    ):
        raise CRAError("succession predecessor identity is not the frozen v0.2 release")
    destination = account.get("destination", {})
    if (
        destination.get("release") != "CRA v1.1"
        or destination.get("status_inherited") is not False
        or destination.get("binding") != "COMPUTED_FROM_CURRENT_NORMATIVE_SOURCE"
    ):
        raise CRAError("succession destination identity/status contract is invalid")
    relation_set = {"PRESERVE", "TRANSFORM", "SPLIT", "MERGE", "RETIRE", "INTRODUCE", "CARRY_OPEN"}

    def dispositions(name: str, expected: set[str]) -> list[dict[str, Any]]:
        rows = account.get(name)
        if not isinstance(rows, list) or any(not isinstance(row, dict) for row in rows):
            raise CRAError(f"succession {name} is absent or malformed")
        identities = [row.get("source_id") for row in rows]
        if set(identities) != expected or len(identities) != len(expected):
            raise CRAError(f"succession {name} does not account its exact predecessor universe")
        for row in rows:
            relation = row.get("relation")
            destinations = row.get("destination_refs")
            if relation not in relation_set or not isinstance(destinations, list) or any(not isinstance(item, str) or not item for item in destinations):
                raise CRAError(f"succession disposition is untyped: {row.get('source_id')}")
            if relation == "RETIRE":
                if destinations or not isinstance(row.get("residual"), str) or not row.get("residual") or not isinstance(row.get("rationale"), str) or not row.get("rationale"):
                    raise CRAError(f"retirement lacks rationale/residual: {row.get('source_id')}")
            elif not destinations:
                raise CRAError(f"succession mapping has no destination: {row.get('source_id')}")
        return rows

    root_rows = dispositions("root_dispositions", V02_ROOT_IDS)
    law_rows = dispositions("law_dispositions", V02_LAW_IDS)
    profile_rows = dispositions("profile_dispositions", V02_PROFILE_IDS)
    frontiers = account.get("frontier_dispositions")
    if not isinstance(frontiers, list) or any(not isinstance(row, dict) for row in frontiers):
        raise CRAError("frontier disposition ledger is absent")
    frontier_ids = [row.get("id") for row in frontiers]
    if set(frontier_ids) != V02_FRONTIER_IDS or len(frontier_ids) != len(V02_FRONTIER_IDS):
        raise CRAError("frontier disposition ledger omits or duplicates a predecessor frontier")
    for row in frontiers:
        required = {
            "id", "source_id", "relation", "status", "owner", "destination_ref",
            "closure_predicate", "closure_claimed", "closure_evidence_refs", "reentry",
        }
        if not required <= set(row) or row.get("source_id") != row.get("id"):
            raise CRAError(f"frontier disposition is incomplete: {row.get('id')}")
        if row.get("relation") != "CARRY_OPEN" or row.get("status") != "OPEN" or row.get("closure_claimed") is not False:
            raise CRAError(f"frontier status was inherited, closed, or transformed without evidence: {row.get('id')}")
        if row.get("closure_evidence_refs") != []:
            raise CRAError(f"OPEN frontier carries unsupported closure evidence: {row.get('id')}")
        if any(not isinstance(row.get(field), str) or not row.get(field) for field in ("owner", "destination_ref", "closure_predicate", "reentry")):
            raise CRAError(f"frontier lacks owner, closure, destination, or reentry: {row.get('id')}")
    evidence = account.get("evidence_disposition", {})
    if evidence.get("predecessor_status") != "ARCHIVED_E1_NOT_INHERITED" or evidence.get("destination_evidence_required") != "V1.1_EXECUTED_EVIDENCE_ONLY":
        raise CRAError("succession evidence status is inherited or ambiguous")
    carriers = account.get("carrier_dispositions")
    if not isinstance(carriers, list) or not carriers or any(
        not isinstance(row, dict)
        or row.get("relation") not in {"PRESERVE", "TRANSFORM", "INTRODUCE", "RETIRE"}
        or not isinstance(row.get("source_id"), str)
        or not isinstance(row.get("destination_refs"), list)
        for row in carriers
    ):
        raise CRAError("succession carrier account is absent or malformed")
    material = {
        "roots": root_rows,
        "laws": law_rows,
        "profiles": profile_rows,
        "frontiers": frontiers,
        "evidence": evidence,
        "carriers": carriers,
    }
    return {
        "roots": len(root_rows),
        "laws": len(law_rows),
        "profiles": len(profile_rows),
        "frontiers": len(frontiers),
        "fingerprint": digest_object(material, "SUCCESSION-ACCOUNT"),
    }


def validate_source(source: dict[str, Any]) -> dict[str, Any]:
    required = {
        "release",
        "purpose",
        "core",
        "scope",
        "index",
        "roots",
        "derived",
        "outcomes",
        "operators",
        "laws",
        "profiles",
        "behaviors",
        "failures",
        "boundaries",
        "claim_ledger",
        "readable_projection",
        "mutation_contract",
        "coverage_contract",
        "reference_profile",
        "lineage",
        "open_certificate_contract",
        "profile_qualification",
    }
    missing = sorted(required - set(source))
    if missing:
        raise CRAError(f"source sections missing: {missing}")
    if source["release"].get("version") != VERSION:
        raise CRAError("release version does not match interpreter")
    index = source_index(source)
    behavior_ids = {row["id"] for row in source["behaviors"]}
    failure_ids = {row["id"] for row in source["failures"]}
    claim_ids = {row["id"] for row in source["claim_ledger"]}

    for behavior in source["behaviors"]:
        implementations = behavior.get("implemented_by")
        if (
            not string_list(implementations, unique=True)
            or not implementations
            or any(not callable(globals().get(name)) for name in implementations)
        ):
            raise CRAError(
                f"behavior {behavior['id']} names no loaded executable implementation: {implementations}"
            )
    for law in source["laws"]:
        dangling = set(law.get("behavior_refs", [])) - behavior_ids
        if dangling:
            raise CRAError(f"law {law['id']} has dangling behavior refs: {sorted(dangling)}")
    for claim in source["claim_ledger"]:
        refs = ([claim["source_id"]] if "source_id" in claim else claim.get("source_ids", []))
        if not refs:
            raise CRAError(f"claim {claim['id']} has no source")
        for ref in refs:
            if ref not in index:
                raise CRAError(f"claim {claim['id']} references missing source {ref}")
            if "public" not in index[ref]:
                raise CRAError(f"readable source {ref} has no public projection")
    projected: list[str] = []
    for section in source["readable_projection"]:
        for ref in section.get("claim_refs", []):
            if ref not in claim_ids:
                raise CRAError(f"readable projection references missing claim {ref}")
            projected.append(ref)
    if set(projected) != claim_ids or len(projected) != len(claim_ids):
        raise CRAError("readable projection must include every claim ledger ID exactly once")
    if len(source["roots"]) != 7 or len(source["laws"]) != 6:
        raise CRAError("v1.1 constitution requires seven roots and six laws")
    outcomes = {row["name"] for row in source["outcomes"]}
    if outcomes != {"EARNED", "REJECTED", "OPEN"}:
        raise CRAError("outcome algebra drift")
    for failure in source["failures"]:
        if failure.get("outcome") not in {"REJECTED", "OPEN"}:
            raise CRAError(f"invalid failure outcome: {failure['id']}")
    if len(failure_ids) != len(source["failures"]):
        raise CRAError("duplicate failure IDs")
    mutation_ids: set[str] = set()
    for mutation in source["mutation_contract"]:
        if mutation.get("id") in mutation_ids:
            raise CRAError(f"duplicate mutation contract ID: {mutation.get('id')}")
        mutation_ids.add(mutation["id"])
        if mutation.get("behavior") not in behavior_ids or mutation.get("failure") not in failure_ids:
            raise CRAError(f"mutation contract {mutation['id']} has a dangling behavior/failure")
        decode_pointer(mutation.get("path", ""))
    for behavior in source["behaviors"]:
        expected_mutations = {
            row["id"] for row in source["mutation_contract"] if row["behavior"] == behavior["id"]
        }
        if set(behavior.get("mutation_refs", [])) != expected_mutations:
            raise CRAError(f"behavior {behavior['id']} does not enumerate its exact mutation clauses")
    open_contract = source.get("open_certificate_contract", {})
    if (
        open_contract.get("schema") != "cra.open/1.1"
        or open_contract.get("first_break_policy") != "FIRST_FAILED_PRECONDITION"
        or open_contract.get("weaker_result_policy") != "DEEPEST_INDEPENDENTLY_VERIFIED_PREFIX_OR_NONE_EARNED"
        or open_contract.get("reentry_policy") != "EARLIEST_INVALIDATED_DEPENDENCY"
        or open_contract.get("standing_policy") != "NO_STANDING_OR_EFFECT_INFERRED"
    ):
        raise CRAError("OpenCertificate normative contract is incomplete")
    profile_qualification = source.get("profile_qualification", {})
    cells = profile_qualification.get("cells")
    if not isinstance(cells, list) or not cells or any(not isinstance(row, dict) for row in cells):
        raise CRAError("profile×dimension qualification ledger is absent")
    cell_ids = [row.get("id") for row in cells]
    if any(not isinstance(item, str) or not item for item in cell_ids) or len(cell_ids) != len(set(cell_ids)):
        raise CRAError("profile qualification cell identity is missing or duplicated")
    for row in cells:
        if row.get("status") not in {"E1_EXECUTED_FINITE", "SPECIFIED_NOT_EXECUTED", "EXTERNAL_PROFILE_REQUIRED"}:
            raise CRAError(f"profile cell has invalid status: {row.get('id')}")
        if not isinstance(row.get("dimensions"), dict) or not row.get("dimensions"):
            raise CRAError(f"profile cell lacks exact dimensions: {row.get('id')}")
        evidence_refs = row.get("evidence_vectors")
        if row.get("status") == "E1_EXECUTED_FINITE" and (not string_list(evidence_refs, unique=True) or not evidence_refs):
            raise CRAError(f"executed profile cell lacks vector evidence: {row.get('id')}")
        if row.get("status") != "E1_EXECUTED_FINITE" and evidence_refs != []:
            raise CRAError(f"unexecuted profile cell claims evidence: {row.get('id')}")
    succession_report = validate_succession_contract(source["lineage"])
    normative = copy.deepcopy(source)
    return {
        "source_ids": len(index),
        "claims": len(claim_ids),
        "behaviors": len(behavior_ids),
        "failures": len(failure_ids),
        "mutation_targets": len(mutation_ids),
        "profile_cells": len(cells),
        "succession": succession_report,
        "architecture_fingerprint": digest_object(normative, "ARCHITECTURE"),
    }


def validate_lexicon(lexicon: Any) -> dict[str, Any]:
    """Validate the optional, manifest-bound, explicitly nonnormative terminology index."""
    if not isinstance(lexicon, dict):
        raise CRAError("Structural Lexicon is absent or malformed")
    if (
        lexicon.get("version") != VERSION
        or lexicon.get("role") != "NONNORMATIVE_SUPPORT_INDEX"
        or lexicon.get("authority") != "NONE"
        or lexicon.get("normative_source") != str(SOURCE_REL)
    ):
        raise CRAError("Structural Lexicon claims authority or mismatches the release")
    entries = lexicon.get("entries")
    categories = lexicon.get("categories")
    statuses = {"CORE", "SUPPORT", "PROFILE", "APPLICATION", "OPEN_FRONTIER", "RETIRED", "SUPERSEDED"}
    required = {
        "term_id", "sense_id", "canonical_label", "aliases", "category", "lineage",
        "status", "activation_trigger", "exclusions", "destination_refs",
    }
    if not isinstance(entries, list) or not entries or any(not isinstance(row, dict) or not required <= set(row) for row in entries):
        raise CRAError("Structural Lexicon entry contract is incomplete")
    for field in ("term_id", "sense_id"):
        values = [row.get(field) for row in entries]
        if any(not isinstance(value, str) or not value for value in values) or len(values) != len(set(values)):
            raise CRAError(f"Structural Lexicon has missing or duplicated {field}")
    for row in entries:
        if (
            not isinstance(row.get("canonical_label"), str)
            or not row.get("canonical_label")
            or not string_list(row.get("aliases"), unique=True)
            or row.get("status") not in statuses
            or not isinstance(row.get("activation_trigger"), str)
            or not row.get("activation_trigger")
            or not string_list(row.get("exclusions"), unique=True)
            or not string_list(row.get("destination_refs"), unique=True)
            or not isinstance(row.get("lineage"), list)
            or not row.get("lineage")
        ):
            raise CRAError(f"Structural Lexicon entry is ill typed: {row.get('term_id')}")
        if row.get("status") == "CORE" and not row.get("destination_refs"):
            raise CRAError(f"CORE lexicon entry has no normative destination: {row.get('term_id')}")
    if not isinstance(categories, list) or any(not isinstance(row, dict) for row in categories):
        raise CRAError("Structural Lexicon category ledger is absent")
    category_counts = Counter(row["category"] for row in entries)
    declared_counts = {row.get("id"): row.get("entry_count") for row in categories}
    if declared_counts != dict(category_counts):
        raise CRAError("Structural Lexicon category counts drift")
    return {
        "entries": len(entries),
        "categories": len(categories),
        "fingerprint": digest_object(lexicon, "STRUCTURAL-LEXICON"),
        "role": lexicon["role"],
    }


def parse_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        try:
            row = strict_json_loads(line)
        except CRAError as exc:
            raise CRAError(f"invalid JSONL at {path}:{number}: {exc}") from exc
        if not isinstance(row, dict):
            raise CRAError(f"JSONL row {number} is not an object")
        rows.append(row)
    return rows


def operative_basis_material(basis: dict[str, Any]) -> dict[str, Any]:
    excluded = {"fingerprint", "comment", "display_name"}
    return {key: value for key, value in basis.items() if key not in excluded}


def basis_fingerprint(basis: dict[str, Any], case: dict[str, Any]) -> str:
    regime_ref = basis.get("regime_ref")
    demand_ref = basis.get("demand_ref")
    material = {
        "basis": operative_basis_material(basis),
        "regime": case.get("regimes", {}).get(regime_ref),
        "demand": case.get("demands", {}).get(demand_ref),
    }
    return digest_object(material, "INDEXED-BASIS")


def seal_case(case: dict[str, Any]) -> dict[str, Any]:
    sealed = copy.deepcopy(case)
    for basis in sealed.get("bases", {}).values():
        basis["fingerprint"] = basis_fingerprint(basis, sealed)
    return sealed


def decode_pointer(pointer: str) -> list[str]:
    if pointer == "":
        return []
    if not pointer.startswith("/"):
        raise CRAError(f"invalid JSON pointer: {pointer}")
    return [part.replace("~1", "/").replace("~0", "~") for part in pointer[1:].split("/")]


def pointer_parent(value: Any, pointer: str) -> tuple[Any, str]:
    parts = decode_pointer(pointer)
    if not parts:
        raise CRAError("mutation cannot target document root")
    current = value
    for part in parts[:-1]:
        if isinstance(current, list):
            current = current[int(part)]
        else:
            current = current[part]
    return current, parts[-1]


MISSING = object()


def pointer_get(value: Any, pointer: str, default: Any = MISSING) -> Any:
    try:
        current = value
        for part in decode_pointer(pointer):
            current = current[int(part)] if isinstance(current, list) else current[part]
        return current
    except (KeyError, IndexError, TypeError, ValueError):
        if default is MISSING:
            raise
        return default


def string_list(value: Any, *, unique: bool = False) -> bool:
    return (
        isinstance(value, list)
        and all(isinstance(item, str) and item for item in value)
        and (not unique or len(value) == len(set(value)))
    )


def integer(value: Any) -> bool:
    """JSON integer, excluding booleans (which subclass int in Python)."""
    return isinstance(value, int) and not isinstance(value, bool)


def apply_mutations(case: dict[str, Any], mutations: list[dict[str, Any]]) -> dict[str, Any]:
    result = copy.deepcopy(case)
    for mutation in mutations:
        op = mutation["op"]
        if op == "reseal":
            parts = decode_pointer(mutation["path"])
            target: Any = result
            for part in parts:
                target = target[int(part)] if isinstance(target, list) else target[part]
            if not isinstance(target, dict):
                raise CRAError(f"reseal target is not an object: {mutation['path']}")
            target["fingerprint"] = basis_fingerprint(target, result)
            continue
        parent, key = pointer_parent(result, mutation["path"])
        if op == "set":
            if isinstance(parent, list):
                parent[int(key)] = copy.deepcopy(mutation.get("value"))
            else:
                parent[key] = copy.deepcopy(mutation.get("value"))
        elif op == "delete":
            if isinstance(parent, list):
                del parent[int(key)]
            else:
                parent.pop(key, None)
        elif op == "append":
            target = parent[int(key)] if isinstance(parent, list) else parent[key]
            if not isinstance(target, list):
                raise CRAError(f"append target is not a list: {mutation['path']}")
            target.append(copy.deepcopy(mutation.get("value")))
        else:
            raise CRAError(f"unknown mutation op: {op}")
    return result


def load_vector_model(path: Path) -> tuple[dict[str, dict[str, Any]], list[dict[str, Any]]]:
    fixtures: dict[str, dict[str, Any]] = {}
    vectors: list[dict[str, Any]] = []
    fixture_patches: list[dict[str, Any]] = []
    ids: set[str] = set()
    for row in parse_jsonl(path):
        row_id = row.get("id")
        if not isinstance(row_id, str) or row_id in ids:
            raise CRAError(f"missing or duplicate vector row id: {row_id}")
        ids.add(row_id)
        if row.get("row_type") == "fixture":
            fixtures[row_id] = seal_case(row["case"])
        elif row.get("row_type") == "fixture_patch":
            fixture_patches.append(row)
        elif row.get("row_type") == "vector":
            vectors.append(row)
        else:
            raise CRAError(f"unknown row_type in {row_id}")
    for patch in fixture_patches:
        target = patch.get("target")
        if target not in fixtures:
            raise CRAError(f"fixture patch {patch['id']} has missing target {target}")
        fixtures[target] = apply_mutations(fixtures[target], patch.get("mutations", []))
    for vector in vectors:
        if vector.get("base") not in fixtures:
            raise CRAError(f"vector {vector['id']} has missing base {vector.get('base')}")
    return fixtures, vectors


@dataclass
class Finding:
    code: str
    detail: str
    behavior: str


@dataclass
class Evaluation:
    outcome: str = "EARNED"
    findings: list[Finding] = field(default_factory=list)
    behaviors: set[str] = field(default_factory=set)
    trace: list[str] = field(default_factory=list)
    reverse: list[str] = field(default_factory=list)
    value: dict[str, Any] | None = None
    witness_bundle: dict[str, Any] = field(default_factory=dict)
    affected_returns: list[str] = field(default_factory=list)
    assumptions: list[str] = field(default_factory=list)
    recovery_ports: list[str] = field(default_factory=list)
    operation: str = "unknown"
    open_certificate: dict[str, Any] | None = None
    _proof_artifacts: list[dict[str, Any]] = field(default_factory=list, repr=False)

    def add(self, code: str, detail: str, behavior: str, failure_outcomes: dict[str, str]) -> None:
        self.findings.append(Finding(code, detail, behavior))
        self.behaviors.add(behavior)
        severity = failure_outcomes[code]
        if severity == "REJECTED" or self.outcome == "REJECTED":
            self.outcome = "REJECTED"
        elif severity == "OPEN":
            self.outcome = "OPEN"

    @property
    def failure_codes(self) -> list[str]:
        return sorted({row.code for row in self.findings})

    def offer_proof_artifact(self, artifact_type: str, value: dict[str, Any], witness: dict[str, Any]) -> None:
        """Record a lawful partial artifact only after its verifier has completed."""
        material = {
            "type": artifact_type,
            "value": copy.deepcopy(value),
            "witness": copy.deepcopy(witness),
        }
        material["fingerprint"] = digest_object(material, "OPEN-PROOF-ARTIFACT")
        self._proof_artifacts.append(material)

    def as_dict(self) -> dict[str, Any]:
        material = {
            "outcome": self.outcome,
            "failures": self.failure_codes,
            "findings": [row.__dict__ for row in self.findings],
            "behaviors": sorted(self.behaviors),
            "forward_trace": self.trace,
            "reverse_trace": self.reverse,
            "value": self.value,
            "witness_bundle": self.witness_bundle,
            "affected_returns": self.affected_returns,
            "assumptions": self.assumptions,
            "recovery_ports": self.recovery_ports,
        }
        if self.outcome == "OPEN":
            material["open_certificate"] = self.open_certificate
        return material


RECOVERY_BY_FAILURE = {
    "F-CLOSURE-OPEN": "supply a certified complete Basis or expose an accepted open port",
    "F-VERIFIER-OPEN": "supply an executable verifier declared by the local Regime",
    "F-LOSS-OPEN": "remove the loss or supply the Demand-authorized typed residual",
    "F-JUDGMENT-OPEN": "earn a current destination-local Judgment",
    "F-STANDING-OPEN": "execute destination policy and admission under current authority",
    "F-ATOMICITY-OPEN": "attach a separately qualified storage/effect provider profile",
    "F-COMPOSE-OPEN": "repair the incompatible composition obligation",
    "F-REASSESS-OPEN": "prove every changed dependency equivalent or re-earn the result",
}


def _operation_demand_ref(case: dict[str, Any]) -> str | None:
    operation = case.get("operation")
    bases = case.get("bases", {})
    basis_id: Any = None
    if operation == "contextualize":
        basis_id = case.get("basis_ref")
    elif operation in {"judge", "admit"}:
        judgment = case.get("judgment", {})
        if isinstance(judgment, dict):
            demand_ref = judgment.get("demand_ref")
            if isinstance(demand_ref, str):
                return demand_ref
            basis_id = judgment.get("basis_ref")
    elif operation in {"rebind", "apply"}:
        crossing = case.get("crossing", {})
        if isinstance(crossing, dict):
            basis_id = crossing.get("destination_basis_ref")
    if isinstance(basis_id, str) and isinstance(bases, dict):
        basis = bases.get(basis_id)
        if isinstance(basis, dict) and isinstance(basis.get("demand_ref"), str):
            return basis["demand_ref"]
    if operation == "reassess":
        new_basis = case.get("new_basis", {})
        if isinstance(new_basis, dict) and isinstance(new_basis.get("demand_ref"), str):
            return new_basis["demand_ref"]
    return None


def _affected_return_components(case: dict[str, Any]) -> list[dict[str, Any]]:
    operation = case.get("operation", "unknown")
    demand_ref = _operation_demand_ref(case)
    demands = case.get("demands", {})
    if isinstance(demand_ref, str) and isinstance(demands, dict):
        demand = demands.get(demand_ref)
        if isinstance(demand, dict) and isinstance(demand.get("return"), str):
            return [{
                "demand_ref": demand_ref,
                "component": "return",
                "path": f"/demands/{demand_ref}/return",
                "return": demand["return"],
            }]
    if operation == "compose":
        demand = case.get("composition_demand", {})
        if isinstance(demand, dict) and isinstance(demand.get("id"), str):
            return [{
                "demand_ref": demand["id"],
                "component": "composite_correspondence",
                "path": "/composite",
                "return": "composite Correspondence",
            }]
    operation_components = {
        "projection": ("projection", "/projection", "Demand-relative projection certificate"),
        "effect": ("effect", "/effect", "effect-stage trace certificate"),
        "carrier": ("carrier", "/", "carrier certificate"),
        "reassess": ("reassessment", "/old_result", "reassessment disposition"),
    }
    component, path, requested = operation_components.get(
        operation, ("operator_result", "/operation", f"{operation} result")
    )
    return [{
        "demand_ref": demand_ref or f"operation:{operation}",
        "component": component,
        "path": path,
        "return": requested,
    }]


def _verified_prefix(result: Evaluation) -> dict[str, Any]:
    if not result._proof_artifacts:
        return {
            "type": "NONE_EARNED",
            "reason": "No typed stage completed before the first unavailable prerequisite.",
        }
    artifacts = copy.deepcopy(result._proof_artifacts)
    return {
        "type": "VerifiedPrefixCertificate",
        "highest_verified_stage": artifacts[-1]["type"],
        "artifacts": artifacts,
        "prefix_fingerprint": digest_object(artifacts, "OPEN-VERIFIED-PREFIX"),
    }


def _live_obligations(case: dict[str, Any], owner: str) -> list[dict[str, Any]]:
    obligations: list[dict[str, Any]] = []
    bases = case.get("bases", {})
    if not isinstance(bases, dict):
        return obligations
    for basis_id, basis in sorted(bases.items()):
        if not isinstance(basis, dict):
            continue
        closure = basis.get("closure", {})
        members = set(closure.get("members", [])) if isinstance(closure, dict) else set()
        for occurrence in basis.get("occurrences", []):
            if not isinstance(occurrence, dict) or occurrence.get("type") != "obligation" or occurrence.get("id") not in members:
                continue
            value = occurrence.get("value", {})
            if not isinstance(value, dict):
                continue
            obligations.append({
                "id": f"LIVE-{occurrence.get('id')}",
                "kind": "DISCLOSED_RESOURCE_OBLIGATION",
                "owner": value.get("owner", owner),
                "status": value.get("status", "OPEN"),
                "requirement": value.get("duty", "typed obligation"),
                "dependency_ref": f"/bases/{basis_id}/occurrences/{occurrence.get('id')}",
            })
    return obligations


def validate_open_certificate(certificate: Any) -> list[str]:
    issues: list[str] = []
    required = {
        "type", "schema", "operation", "first_break", "weaker_result", "standing_ceiling",
        "remaining_obligations", "affected_return_components", "reverse_evidence",
        "smallest_reentry", "detection_scope", "certificate_fingerprint",
    }
    if not isinstance(certificate, dict) or not required <= set(certificate):
        return ["missing typed OpenCertificate fields"]
    if certificate.get("type") != "OpenCertificate":
        issues.append("wrong certificate type")
    if certificate.get("schema") != "cra.open/1.1":
        issues.append("wrong certificate schema")
    first_break = certificate.get("first_break")
    if not isinstance(first_break, dict) or not {
        "operator", "stage", "requirement", "failure_code", "dependency_ref"
    } <= set(first_break):
        issues.append("first break is incomplete")
    weaker = certificate.get("weaker_result")
    if not isinstance(weaker, dict) or weaker.get("type") not in {"NONE_EARNED", "VerifiedPrefixCertificate"}:
        issues.append("weaker result is untyped")
    if certificate.get("standing_ceiling") not in {"NONE_EARNED", "JUDGMENT_ONLY", "STANDING_ONLY_NO_EFFECT"}:
        issues.append("Standing ceiling is invalid")
    obligations = certificate.get("remaining_obligations")
    if not isinstance(obligations, list) or not obligations or any(
        not isinstance(row, dict) or not {"id", "kind", "owner", "status", "requirement", "dependency_ref"} <= set(row)
        for row in obligations
    ):
        issues.append("remaining obligation frontier is incomplete")
    affected = certificate.get("affected_return_components")
    if not isinstance(affected, list) or not affected or any(
        not isinstance(row, dict) or not {"demand_ref", "component", "path", "return"} <= set(row)
        for row in affected
    ):
        issues.append("affected Return components are incomplete")
    reentry = certificate.get("smallest_reentry")
    if not isinstance(reentry, dict) or not {"dependency_ref", "port", "action"} <= set(reentry):
        issues.append("smallest reentry is incomplete")
    if not isinstance(certificate.get("reverse_evidence"), list) or not certificate["reverse_evidence"]:
        issues.append("reverse evidence is absent")
    fingerprint = certificate.get("certificate_fingerprint")
    fingerprint_material = copy.deepcopy(certificate)
    fingerprint_material.pop("certificate_fingerprint", None)
    if not isinstance(fingerprint, str) or fingerprint != digest_object(fingerprint_material, "OPEN-CERTIFICATE/1.1"):
        issues.append("certificate fingerprint mismatch")
    return issues


def finalize_evaluation(case: dict[str, Any], result: Evaluation) -> Evaluation:
    if result.outcome != "OPEN":
        return result
    result.operation = str(case.get("operation", "unknown"))
    first = result.findings[0]
    affected_components = _affected_return_components(case)
    result.affected_returns = [
        f"{row['demand_ref']}:{row['component']}:{row['return']}" for row in affected_components
    ]
    demands = case.get("demands", {})
    demand_ref = _operation_demand_ref(case)
    demand = demands.get(demand_ref, {}) if isinstance(demands, dict) and isinstance(demand_ref, str) else {}
    result.assumptions = sorted(
        item for item in demand.get("accepted_assumptions", []) if isinstance(item, str)
    ) if isinstance(demand, dict) else []
    recovery = RECOVERY_BY_FAILURE.get(first.code, "supply the missing local proof obligation")
    dependency_ref = affected_components[0]["path"]
    owner = "destination-local operator"
    if isinstance(demand, dict) and isinstance(demand.get("regime_ref"), str):
        owner = demand["regime_ref"]
    proof_obligation = {
        "id": f"OPEN-{digest_object({'operation': result.operation, 'code': first.code, 'behavior': first.behavior, 'detail': first.detail}, 'OPEN-OBLIGATION')[:16]}",
        "kind": "DETECTED_PROOF_OBLIGATION",
        "owner": owner,
        "status": "OPEN",
        "requirement": first.detail,
        "dependency_ref": dependency_ref,
    }
    remaining = [proof_obligation, *_live_obligations(case, owner)]
    deduplicated: dict[str, dict[str, Any]] = {row["id"]: row for row in remaining}
    weaker_result = _verified_prefix(result)
    standing_ceiling = "NONE_EARNED"
    if any(item.startswith("admit:") for item in result.trace):
        standing_ceiling = "STANDING_ONLY_NO_EFFECT"
    elif any(item.startswith("judge:") for item in result.trace):
        standing_ceiling = "JUDGMENT_ONLY"
    reverse_evidence = list(result.reverse) or [
        f"break:{first.code}",
        *(f"verified:{item}" for item in reversed(result.trace)),
        f"dependency:{dependency_ref}",
    ]
    result.open_certificate = {
        "type": "OpenCertificate",
        "schema": "cra.open/1.1",
        "operation": result.operation,
        "first_break": {
            "operator": result.operation,
            "stage": first.behavior,
            "requirement": first.detail,
            "failure_code": first.code,
            "dependency_ref": dependency_ref,
        },
        "weaker_result": weaker_result,
        "standing_ceiling": standing_ceiling,
        "remaining_obligations": list(deduplicated.values()),
        "affected_return_components": affected_components,
        "reverse_evidence": reverse_evidence,
        "smallest_reentry": {
            "dependency_ref": dependency_ref,
            "port": first.code,
            "action": recovery,
        },
        "detection_scope": "FIRST_FAILED_PRECONDITION_PLUS_DISCLOSED_LIVE_OBLIGATIONS",
    }
    result.open_certificate["certificate_fingerprint"] = digest_object(
        result.open_certificate, "OPEN-CERTIFICATE/1.1"
    )
    result.recovery_ports = [recovery]
    return result


def occurrence_map(basis: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {row["id"]: row for row in basis.get("occurrences", [])}


def closure_from(seeds: list[str], edges: list[dict[str, str]]) -> set[str]:
    predecessors: dict[str, set[str]] = defaultdict(set)
    for edge in edges:
        predecessors[edge["to"]].add(edge["from"])
    seen: set[str] = set()
    queue = deque(seeds)
    while queue:
        item = queue.popleft()
        if item in seen:
            continue
        seen.add(item)
        queue.extend(predecessors.get(item, ()))
    return seen


def get_basis(case: dict[str, Any], basis_id: str) -> dict[str, Any] | None:
    return case.get("bases", {}).get(basis_id)


def validate_basis(
    case: dict[str, Any], basis_id: str, result: Evaluation, outcomes: dict[str, str]
) -> bool:
    basis = get_basis(case, basis_id)
    result.behaviors.update({"B-INDEX", "B-BASIS", "B-CLOSURE"})
    if not isinstance(basis, dict):
        result.add("F-INDEX", f"missing Basis {basis_id}", "B-INDEX", outcomes)
        return False
    if not integer(case.get("at")):
        result.add("F-INTEGRITY", "case lacks an explicit integer evaluation time", "B-BASIS", outcomes)
        return False
    demand = case.get("demands", {}).get(basis.get("demand_ref"))
    regime = case.get("regimes", {}).get(basis.get("regime_ref"))
    if not isinstance(demand, dict) or not isinstance(regime, dict) or demand.get("regime_ref") != basis.get("regime_ref"):
        result.add("F-INDEX", f"Basis {basis_id} has a broken Regime/Demand index", "B-INDEX", outcomes)
        return False
    if (
        basis.get("id") != basis_id
        or not isinstance(basis.get("operator"), str)
        or not basis.get("operator")
        or not isinstance(basis.get("versions"), dict)
        or not isinstance(basis.get("times"), dict)
        or not isinstance(basis.get("occurrences"), list)
        or not isinstance(basis.get("dependencies"), list)
        or not isinstance(basis.get("closure"), dict)
        or not isinstance(basis.get("open_ports"), list)
        or not isinstance(basis.get("policies"), list)
        or not isinstance(basis.get("authorities"), list)
        or not isinstance(basis.get("trusted_roots"), list)
    ):
        result.add("F-INTEGRITY", f"Basis {basis_id} lacks a mandatory typed field", "B-BASIS", outcomes)
        return False
    if not isinstance(regime.get("resource_laws"), dict) or not regime.get("resource_laws"):
        result.behaviors.add("B-RESOURCE")
        result.add("F-VERIFIER-OPEN", f"Regime for Basis {basis_id} lacks local resource laws", "B-RESOURCE", outcomes)
        return False
    if regime.get("id") != basis.get("regime_ref") or not valid_regime_shape(regime):
        result.add("F-VERIFIER-OPEN", f"Regime for Basis {basis_id} lacks the executable finite capability interface", "B-BASIS", outcomes)
        return False
    if not executable_regime_shape(regime):
        result.add("F-VERIFIER-OPEN", f"Regime for Basis {basis_id} has an unexecutable reference interface", "B-BASIS", outcomes)
        return False
    if basis.get("operator") not in regime.get("capabilities", []):
        result.add("F-VERIFIER-OPEN", f"Regime for Basis {basis_id} does not expose the requested operator capability", "B-BASIS", outcomes)
        return False
    horizon = demand.get("horizon")
    demand_required = (
        demand.get("id") == basis.get("demand_ref")
        and isinstance(demand.get("return"), str)
        and bool(demand.get("return"))
        and isinstance(demand.get("return_type"), str)
        and bool(demand.get("return_type"))
        and isinstance(demand.get("accept"), str)
        and bool(demand.get("accept"))
        and isinstance(demand.get("approx"), str)
        and bool(demand.get("approx"))
        and string_list(demand.get("inputs"), unique=True)
        and string_list(demand.get("protected"), unique=True)
        and isinstance(demand.get("use"), str)
        and bool(demand.get("use"))
        and isinstance(demand.get("required_standing"), bool)
        and isinstance(demand.get("seeds"), dict)
        and string_list(demand.get("accepted_assumptions"), unique=True)
        and string_list(demand.get("acceptable_losses"), unique=True)
        and isinstance(horizon, list)
        and len(horizon) == 2
        and all(integer(item) for item in horizon)
        and horizon[0] <= horizon[1]
    )
    seeds = demand.get("seeds", {}).get(basis.get("operator")) if isinstance(demand.get("seeds"), dict) else None
    if not demand_required or not string_list(seeds, unique=True) or not seeds or demand.get("return") not in regime.get("sentences", []):
        result.add("F-CLOSURE-OPEN", f"Demand for Basis {basis_id} lacks its complete typed contract", "B-CLOSURE", outcomes)
        return False
    if set(demand.get("inputs", [])) != set(seeds):
        result.add("F-CLOSURE-OPEN", f"Demand for Basis {basis_id} does not bind its exact finite operator inputs", "B-CLOSURE", outcomes)
        return False
    if demand.get("return_type") != "sentence" or demand.get("accept") != "FINITE_SATISFACTION" or demand.get("approx") != "EXACT":
        result.add("F-VERIFIER-OPEN", f"Demand for Basis {basis_id} uses an unimplemented reference relation", "B-CLOSURE", outcomes)
        return False
    if set(basis.get("versions", {})) != {"regime", "policy"} or basis.get("versions", {}).get("regime") != regime.get("version"):
        result.add("F-INDEX", f"Basis {basis_id} binds the wrong Regime version", "B-INDEX", outcomes)
        return False
    declared_verifiers = set(regime.get("verifier_interfaces", []))
    declared_policies = set(regime.get("policy_interfaces", {}))
    if (
        not string_list(basis.get("verifiers"), unique=True)
        or not string_list(basis.get("policies"), unique=True)
        or not set(basis.get("verifiers", [])) <= declared_verifiers
        or not set(basis.get("policies", [])) <= declared_policies
    ):
        result.add("F-VERIFIER-OPEN", f"Basis {basis_id} names an undeclared local verifier or policy", "B-BASIS", outcomes)
        return False
    if set(basis.get("trusted_roots", [])) != set(regime.get("trusted_roots", [])):
        result.behaviors.add("B-AUTHORITY")
        result.add("F-AUTHORITY", f"Basis {basis_id} trust roots differ from its Regime configuration", "B-AUTHORITY", outcomes)
        return False
    if basis.get("fingerprint") != basis_fingerprint(basis, case):
        result.add("F-INTEGRITY", f"Basis {basis_id} fingerprint does not bind current content", "B-BASIS", outcomes)
        return False
    occurrences = basis.get("occurrences", [])
    if any(not isinstance(row, dict) for row in occurrences):
        result.add("F-INTEGRITY", f"Basis {basis_id} contains a malformed occurrence", "B-BASIS", outcomes)
        return False
    occurrence_ids = [row.get("id") for row in occurrences]
    if any(not isinstance(item, str) or not item for item in occurrence_ids) or len(occurrence_ids) != len(set(occurrence_ids)):
        result.add("F-INTEGRITY", f"Basis {basis_id} has missing or duplicate occurrence identity", "B-BASIS", outcomes)
        return False
    if any("value" not in row or not isinstance(row.get("type"), str) or not row.get("type") or not isinstance(row.get("lineage"), str) or not row.get("lineage") for row in occurrences):
        result.add("F-INTEGRITY", f"Basis {basis_id} has an untyped or unlineaged occurrence", "B-BASIS", outcomes)
        return False
    occurrence_types = {row["type"] for row in occurrences}
    if not occurrence_types <= set(regime.get("resource_laws", {})):
        result.behaviors.add("B-RESOURCE")
        result.add("F-VERIFIER-OPEN", f"Basis {basis_id} contains a type with no local resource law", "B-RESOURCE", outcomes)
        return False
    port_types = {port["type"] for port in regime.get("ports", {}).values()}
    for row in occurrences:
        row_type = row["type"]
        value = row["value"]
        if row_type in port_types and (not isinstance(value, str) or value not in regime.get("sentences", [])):
            result.add("F-INTEGRITY", f"Basis {basis_id} has an ill-typed native Claim occurrence", "B-BASIS", outcomes)
            return False
        if row_type == "model" and value not in regime.get("models", []):
            result.add("F-INTEGRITY", f"Basis {basis_id} has an unknown local model occurrence", "B-BASIS", outcomes)
            return False
    policy_rows = [row for row in occurrences if row.get("type") == "policy"]
    policy_specs = regime.get("policy_interfaces", {})
    named_policies = basis.get("policies", [])
    expected_policy_values = [
        {"id": policy_id, **policy_specs[policy_id]}
        for policy_id in named_policies
        if policy_id in policy_specs
    ]
    if Counter(canonical_bytes(row.get("value")) for row in policy_rows) != Counter(
        canonical_bytes(value) for value in expected_policy_values
    ):
        result.add("F-VERIFIER-OPEN", f"Basis {basis_id} policy material differs from its Regime interface", "B-BASIS", outcomes)
        return False
    expected_policy_version = (
        expected_policy_values[0]["version"] if len(expected_policy_values) == 1 else "none"
    )
    if len(expected_policy_values) > 1 or basis.get("versions", {}).get("policy") != expected_policy_version:
        result.add("F-INDEX", f"Basis {basis_id} policy version is unbound or ambiguous", "B-INDEX", outcomes)
        return False
    if not set(demand.get("inputs", [])) <= set(occurrence_ids):
        result.add("F-CLOSURE-OPEN", f"Demand input is absent from Basis {basis_id}", "B-CLOSURE", outcomes)
        return False
    edge_endpoints = {endpoint for edge in basis.get("dependencies", []) for endpoint in (edge.get("from"), edge.get("to"))}
    if None in edge_endpoints or not edge_endpoints <= set(occurrence_ids):
        result.add("F-INTEGRITY", f"Basis {basis_id} dependency edge is dangling", "B-BASIS", outcomes)
        return False
    times = basis.get("times", {})
    if (
        not integer(times.get("snapshot"))
        or not integer(times.get("knowledge"))
        or times["snapshot"] > times["knowledge"]
        or not (horizon[0] <= times["snapshot"] <= horizon[1])
    ):
        result.add("F-INTEGRITY", f"Basis {basis_id} has invalid snapshot/knowledge ordering", "B-BASIS", outcomes)
        return False
    certificate = basis.get("closure", {})
    if (
        certificate.get("checker") != CLOSURE_VERIFIER
        or certificate.get("checker") not in declared_verifiers
        or certificate.get("checker") not in basis.get("verifiers", [])
    ):
        result.add("F-VERIFIER-OPEN", f"Basis {basis_id} has no executable closure checker", "B-CLOSURE", outcomes)
        return False
    if certificate.get("status") != "CERTIFIED":
        result.add("F-CLOSURE-OPEN", f"Basis {basis_id} closure is {certificate.get('status', 'MISSING')}", "B-CLOSURE", outcomes)
        return False
    expected = closure_from(seeds, basis.get("dependencies", []))
    members = certificate.get("members", [])
    if len(members) != len(set(members)):
        result.add("F-CLOSURE-OPEN", f"Basis {basis_id} closure repeats an occurrence", "B-CLOSURE", outcomes)
        return False
    actual = set(members)
    available = set(occurrence_map(basis))
    if actual != expected or not actual <= available:
        result.add("F-CLOSURE-OPEN", f"Basis {basis_id} closure witness is not the exact computed finite slice", "B-CLOSURE", outcomes)
        return False
    protected = set(demand.get("protected", []))
    if not protected <= actual:
        result.add("F-CLOSURE-OPEN", f"Basis {basis_id} omits a Demand-protected occurrence from closure", "B-CLOSURE", outcomes)
        return False
    unresolved = [port for port in basis.get("open_ports", []) if port not in demand.get("accepted_assumptions", [])]
    if unresolved:
        result.add("F-CLOSURE-OPEN", f"Basis {basis_id} has unaccepted open ports: {unresolved}", "B-CLOSURE", outcomes)
        return False
    result.trace.append(f"contextualize:{basis_id}:{','.join(sorted(actual))}")
    result.offer_proof_artifact(
        "Context",
        {
            "basis_ref": basis_id,
            "demand_ref": basis.get("demand_ref"),
            "regime_ref": basis.get("regime_ref"),
            "membrane": sorted(actual),
        },
        {"basis_fingerprint": basis.get("fingerprint"), "closure_checker": certificate.get("checker")},
    )
    return True


def satisfaction(regime: dict[str, Any], model: str, sentence: str) -> bool:
    return sentence in regime.get("satisfaction", {}).get(model, [])


def validate_correspondence(case: dict[str, Any], result: Evaluation, outcomes: dict[str, str]) -> bool:
    correspondence = case.get("correspondence")
    if not isinstance(correspondence, dict):
        result.add("F-VERIFIER-OPEN", "no Correspondence supplied", "B-TYPED", outcomes)
        return False
    result.behaviors.update({"B-TYPED", "B-SEMANTIC", "B-NOSTANDING"})
    if "standing_map" in correspondence or correspondence.get("transports_standing"):
        result.add("F-STANDING-TRANSPORT", "Correspondence attempts to transport Standing", "B-NOSTANDING", outcomes)
        return False
    required = {
        "id", "source_regime", "source_version", "destination_regime", "destination_version",
        "source_port", "destination_port", "source_type", "destination_type", "domain",
        "sentence_map", "model_relation", "guarantee", "loss", "error", "residual",
        "resource_profile", "error_operator", "verifier_ref", "destination_accepted", "validity",
    }
    string_fields = {
        "id", "source_regime", "source_version", "destination_regime", "destination_version",
        "source_port", "destination_port", "source_type", "destination_type", "guarantee",
        "resource_profile", "error_operator", "verifier_ref",
    }
    if (
        not required <= set(correspondence)
        or any(not isinstance(correspondence.get(field), str) or not correspondence.get(field) for field in string_fields)
        or not isinstance(correspondence.get("sentence_map"), dict)
        or not isinstance(correspondence.get("model_relation"), list)
        or not string_list(correspondence.get("loss"), unique=True)
        or not string_list(correspondence.get("residual"), unique=True)
        or not integer(correspondence.get("error"))
        or correspondence.get("error", -1) < 0
        or not isinstance(correspondence.get("destination_accepted"), bool)
        or correspondence.get("resource_profile") not in RESOURCE_RULES
        or correspondence.get("error_operator") not in {"SUM", "MAX"}
    ):
        result.add("F-TYPE", "Correspondence lacks a mandatory typed field", "B-TYPED", outcomes)
        return False
    source = case.get("regimes", {}).get(correspondence.get("source_regime"))
    destination = case.get("regimes", {}).get(correspondence.get("destination_regime"))
    if not valid_regime_shape(source) or not valid_regime_shape(destination) or not executable_regime_shape(source) or not executable_regime_shape(destination):
        result.add("F-TYPE", "Correspondence names a missing Regime", "B-TYPED", outcomes)
        return False
    if correspondence.get("source_version") != source.get("version") or correspondence.get("destination_version") != destination.get("version"):
        result.add("F-TYPE", "Correspondence Regime version mismatch", "B-TYPED", outcomes)
        return False
    crossing = case.get("crossing", {})
    source_bases = [get_basis(case, item) for item in crossing.get("source_basis_refs", [])]
    destination_basis = get_basis(case, crossing.get("destination_basis_ref", ""))
    if (
        not source_bases
        or any(basis is None or basis.get("regime_ref") != correspondence.get("source_regime") for basis in source_bases)
        or destination_basis is None
        or destination_basis.get("regime_ref") != correspondence.get("destination_regime")
    ):
        result.add("F-INDEX", "Crossing Basis Regimes do not match Correspondence endpoints", "B-TYPED", outcomes)
        return False
    source_port = source.get("ports", {}).get(correspondence.get("source_port"))
    destination_port = destination.get("ports", {}).get(correspondence.get("destination_port"))
    if not source_port or not destination_port:
        result.add("F-TYPE", "Correspondence port is absent", "B-TYPED", outcomes)
        return False
    if correspondence.get("source_type") != source_port.get("type") or correspondence.get("destination_type") != destination_port.get("type"):
        result.add("F-TYPE", "Correspondence port type mismatch", "B-TYPED", outcomes)
        return False
    at = case.get("at", 0)
    valid = correspondence.get("validity", [])
    if (
        not isinstance(valid, list)
        or len(valid) != 2
        or any(not integer(item) for item in valid)
        or valid[0] > valid[1]
        or not (valid[0] <= at <= valid[1])
        or not correspondence.get("destination_accepted")
    ):
        result.add("F-TYPE", "Correspondence is invalid or not accepted at destination", "B-TYPED", outcomes)
        return False
    verifier = correspondence.get("verifier_ref")
    if verifier != CORRESPONDENCE_VERIFIER or destination_basis is None or verifier not in destination_basis.get("verifiers", []):
        result.add("F-VERIFIER-OPEN", "Correspondence verifier is outside destination Basis", "B-TYPED", outcomes)
        return False
    destination_demand = case.get("demands", {}).get((destination_basis or {}).get("demand_ref"), {})
    declared_loss = set(correspondence.get("loss", []))
    if declared_loss and (
        not declared_loss <= set(destination_demand.get("acceptable_losses", []))
        or not correspondence.get("residual")
    ):
        result.add("F-LOSS-OPEN", "Correspondence loss is not accepted and residualized by the destination Demand", "B-SEMANTIC", outcomes)
        return False
    mapping = correspondence.get("sentence_map", {})
    domain = correspondence.get("domain", [])
    relation = correspondence.get("model_relation", [])
    if (
        not string_list(domain, unique=True)
        or not domain
        or not relation
        or not isinstance(relation, list)
        or any(not isinstance(pair, list) for pair in relation)
        or len({canonical_bytes(pair) for pair in relation if isinstance(pair, list)}) != len(relation)
        or set(mapping) != set(domain)
    ):
        result.add("F-VERIFIER-OPEN", "semantic Correspondence has no nonempty declared domain/model relation", "B-SEMANTIC", outcomes)
        return False
    if any(sentence not in source.get("sentences", []) for sentence in domain) or any(mapping.get(sentence) not in destination.get("sentences", []) for sentence in domain):
        result.add("F-TYPE", "Correspondence sentence domain/map is ill typed", "B-TYPED", outcomes)
        return False
    if any(
        not isinstance(pair, list)
        or len(pair) != 2
        or pair[0] not in source.get("models", [])
        or pair[1] not in destination.get("models", [])
        for pair in relation
    ):
        result.add("F-TYPE", "Correspondence model relation is ill typed", "B-TYPED", outcomes)
        return False
    relevant_source_models = {
        model for model in source.get("models", []) if any(satisfaction(source, model, sentence) for sentence in domain)
    }
    if any(not any(satisfaction(source, model, sentence) for model in source.get("models", [])) for sentence in domain):
        result.add("F-VERIFIER-OPEN", "Correspondence domain contains a sentence with no finite source witness", "B-SEMANTIC", outcomes)
        return False
    related_source_models = {pair[0] for pair in relation}
    if not relevant_source_models <= related_source_models:
        result.add("F-VERIFIER-OPEN", "Correspondence omits a source model relevant to its declared domain", "B-SEMANTIC", outcomes)
        return False
    guarantee = correspondence.get("guarantee")
    if guarantee in {"PRESERVES", "EXACT"}:
        for pair in correspondence.get("model_relation", []):
            for sentence in domain:
                if satisfaction(source, pair[0], sentence) and not satisfaction(destination, pair[1], mapping[sentence]):
                    result.add("F-GUARANTEE", f"preservation countermodel {pair}/{sentence}", "B-SEMANTIC", outcomes)
                    return False
    if guarantee in {"REFLECTS", "EXACT"}:
        for pair in correspondence.get("model_relation", []):
            for sentence in domain:
                if satisfaction(destination, pair[1], mapping[sentence]) and not satisfaction(source, pair[0], sentence):
                    result.add("F-GUARANTEE", f"reflection countermodel {pair}/{sentence}", "B-SEMANTIC", outcomes)
                    return False
    if guarantee not in {"PRESERVES", "REFLECTS", "EXACT", "PROVENANCE_ONLY", "BOUNDED"}:
        result.add("F-VERIFIER-OPEN", "Correspondence guarantee is absent or unknown", "B-SEMANTIC", outcomes)
        return False
    if guarantee != "BOUNDED" and correspondence.get("error") != 0:
        result.add("F-GUARANTEE", "an unbounded semantic guarantee declares a nonzero error", "B-SEMANTIC", outcomes)
        return False
    if guarantee == "BOUNDED":
        if correspondence.get("metric") not in {"ABS", "DISCRETE_SATISFACTION"}:
            result.add("F-VERIFIER-OPEN", "bounded Correspondence lacks a typed metric and nonnegative bound", "B-SEMANTIC", outcomes)
            return False
        for pair in correspondence.get("model_relation", []):
            for sentence in domain:
                difference = abs(
                    int(satisfaction(source, pair[0], sentence))
                    - int(satisfaction(destination, pair[1], mapping[sentence]))
                )
                if difference > correspondence["error"]:
                    result.add("F-GUARANTEE", f"bounded countermodel {pair}/{sentence} exceeds error", "B-SEMANTIC", outcomes)
                    return False
        if correspondence.get("error", 0) > 0 and not correspondence.get("residual"):
            result.add("F-LOSS-OPEN", "bounded Correspondence lacks a residual", "B-SEMANTIC", outcomes)
            return False
    result.trace.append(f"correspondence:{correspondence['id']}:{guarantee}")
    result.offer_proof_artifact(
        "Correspondence",
        {
            "id": correspondence["id"],
            "source_regime": correspondence["source_regime"],
            "destination_regime": correspondence["destination_regime"],
            "guarantee": guarantee,
        },
        {
            "verifier_ref": correspondence["verifier_ref"],
            "correspondence_fingerprint": digest_object(correspondence, "CORRESPONDENCE"),
        },
    )
    return True


def validate_account(case: dict[str, Any], result: Evaluation, outcomes: dict[str, str]) -> bool:
    crossing = case.get("crossing", {})
    result.behaviors.update({"B-ACCOUNT", "B-RESOURCE", "B-PROVENANCE"})
    if (
        not isinstance(crossing, dict)
        or not CROSSING_FIELDS <= set(crossing)
        or not isinstance(crossing.get("id"), str)
        or not crossing.get("id")
        or not string_list(crossing.get("source_basis_refs"), unique=True)
        or not string_list(crossing.get("source_membrane"), unique=True)
        or not isinstance(crossing.get("destination_basis_ref"), str)
        or not crossing.get("destination_basis_ref")
        or not string_list(crossing.get("produced_targets"), unique=True)
        or not isinstance(crossing.get("account_edges"), list)
        or not string_list(crossing.get("dependencies"), unique=True)
        or not isinstance(crossing.get("validity"), list)
        or len(crossing.get("validity", [])) != 2
        or any(not integer(item) for item in crossing.get("validity", []))
        or crossing.get("validity", [1, 0])[0] > crossing.get("validity", [1, 0])[1]
        or not string_list(crossing.get("loss"))
        or not integer(crossing.get("error"))
        or crossing.get("error", -1) < 0
        or not string_list(crossing.get("residual"))
    ):
        result.add("F-ACCOUNT", "Crossing lacks its explicit typed membrane/account contract", "B-ACCOUNT", outcomes)
        return False
    source_basis_ids = crossing.get("source_basis_refs", [])
    source_occurrences: dict[str, dict[str, Any]] = {}
    source_regimes: dict[str, dict[str, Any]] = {}
    protected_sources: set[str] = set()
    for basis_id in source_basis_ids:
        basis = get_basis(case, basis_id)
        if basis:
            regime = case.get("regimes", {}).get(basis.get("regime_ref"), {})
            demand = case.get("demands", {}).get(basis.get("demand_ref"), {})
            protected_sources |= set(demand.get("protected", []))
            for occurrence_id, occurrence in occurrence_map(basis).items():
                if occurrence_id in source_occurrences:
                    result.add("F-ACCOUNT", f"source occurrence ID reused: {occurrence_id}", "B-ACCOUNT", outcomes)
                    return False
                source_occurrences[occurrence_id] = occurrence
                source_regimes[occurrence_id] = regime
    membrane = crossing.get("source_membrane", [])
    expected_membrane: list[str] = []
    for basis_id in source_basis_ids:
        basis = get_basis(case, basis_id)
        if basis:
            expected_membrane.extend(basis.get("closure", {}).get("members", []))
    if Counter(membrane) != Counter(expected_membrane):
        result.add("F-ACCOUNT", "source membrane differs from certified predecessor closures", "B-ACCOUNT", outcomes)
        return False
    edges = crossing.get("account_edges", [])
    if not isinstance(edges, list) or any(not isinstance(edge, dict) for edge in edges):
        result.add("F-ACCOUNT", "account edges are not typed records", "B-ACCOUNT", outcomes)
        return False
    edge_required = {"id", "sources", "targets", "relation", "witness", "loss", "error", "residual"}
    if any(
        not edge_required <= set(edge)
        or not string_list(edge.get("sources"), unique=True)
        or not string_list(edge.get("targets"), unique=True)
        or not isinstance(edge.get("witness"), dict)
        or not string_list(edge.get("loss"), unique=True)
        or not integer(edge.get("error"))
        or edge.get("error", -1) < 0
        or not string_list(edge.get("residual"), unique=True)
        for edge in edges
    ):
        result.add("F-ACCOUNT", "account edge lacks mandatory typed loss, error, or residual fields", "B-ACCOUNT", outcomes)
        return False
    edge_ids = [edge.get("id") for edge in edges]
    if any(not isinstance(item, str) or not item for item in edge_ids) or len(edge_ids) != len(set(edge_ids)):
        result.add("F-ACCOUNT", "account edge identity is missing or repeated", "B-ACCOUNT", outcomes)
        return False
    explained_sources = [item for edge in edges for item in edge.get("sources", [])]
    explained_targets = [item for edge in edges for item in edge.get("targets", [])]
    produced_targets = crossing.get("produced_targets", [])
    if len(produced_targets) != len(set(produced_targets)):
        result.add("F-ACCOUNT", "produced target occurrence identity is repeated", "B-ACCOUNT", outcomes)
        return False
    if Counter(explained_sources) != Counter(membrane) or Counter(explained_targets) != Counter(produced_targets):
        result.add("F-ACCOUNT", "bilateral occurrence multisets do not partition exactly", "B-ACCOUNT", outcomes)
        return False
    destination_basis = get_basis(case, crossing.get("destination_basis_ref", ""))
    destination_occurrences = occurrence_map(destination_basis or {})
    if not set(produced_targets) <= set(destination_occurrences):
        result.add("F-ACCOUNT", "produced target is absent from destination Basis", "B-PROVENANCE", outcomes)
        return False
    if any(str(destination_occurrences.get(item, {}).get("type", "")).casefold() == "standing" for item in produced_targets):
        result.behaviors.add("B-NOSTANDING")
        result.add("F-STANDING-TRANSPORT", "a Crossing attempts to produce Standing as transported material", "B-NOSTANDING", outcomes)
        return False
    destination_regime = case.get("regimes", {}).get((destination_basis or {}).get("regime_ref"), {})
    for item in produced_targets:
        occurrence = destination_occurrences.get(item, {})
        policy = destination_regime.get("resource_laws", {}).get(occurrence.get("type"))
        if policy not in RESOURCE_RULES:
            result.add("F-VERIFIER-OPEN", f"produced occurrence {item} has no destination resource law", "B-RESOURCE", outcomes)
            return False
    correspondence = case.get("correspondence", {})
    formation = case.get("formation") is True
    at = case.get("at")
    validity = crossing.get("validity", [1, 0])
    expected_dependencies = {crossing.get("destination_basis_ref")}
    if formation:
        constructor_ref = crossing.get("constructor_ref")
        if (
            crossing.get("correspondence_ref") is not None
            or source_basis_ids
            or membrane
            or not isinstance(constructor_ref, str)
            or constructor_ref not in destination_regime.get("constructor_interfaces", [])
        ):
            result.add("F-ACCOUNT", "formation lacks an executable constructor or has a predecessor", "B-ACCOUNT", outcomes)
            return False
        expected_dependencies.add(constructor_ref)
        expected_validity = case.get("demands", {}).get((destination_basis or {}).get("demand_ref"), {}).get("horizon")
    else:
        if (
            not isinstance(correspondence, dict)
            or crossing.get("correspondence_ref") != correspondence.get("id")
            or crossing.get("constructor_ref") is not None
        ):
            result.add("F-INDEX", "Crossing does not bind the applied Correspondence", "B-INDEX", outcomes)
            return False
        expected_dependencies |= set(source_basis_ids) | {correspondence.get("id")}
        expected_validity = correspondence.get("validity")
    if (
        set(crossing.get("dependencies", [])) != expected_dependencies
        or crossing.get("validity") != expected_validity
        or not integer(at)
        or not (validity[0] <= at <= validity[1])
    ):
        result.add("F-INDEX", "Crossing dependencies or validity do not bind this application", "B-INDEX", outcomes)
        return False
    flattened_loss = [item for edge in edges for item in edge.get("loss", [])]
    flattened_residual = [item for edge in edges for item in edge.get("residual", [])]
    expected_error = max((edge.get("error", 0) for edge in edges), default=0)
    if (
        crossing.get("loss") != flattened_loss
        or crossing.get("residual") != flattened_residual
        or crossing.get("error") != expected_error
    ):
        result.add("F-ACCOUNT", "Crossing summary does not equal its edge-level loss, error, and residual", "B-ACCOUNT", outcomes)
        return False
    allowed_relations = {"INTRODUCE", "TRANSLATE", "TRANSFORM", "PRESERVE", "COPY_LICENSED", "SPLIT", "MERGE", "TRANSFER", "DISCHARGE", "LOSS"}
    for edge in edges:
        sources = edge.get("sources", [])
        targets = edge.get("targets", [])
        relation = edge.get("relation")
        witness = edge.get("witness", {})
        if relation not in allowed_relations or not witness or not isinstance(witness.get("verifier"), str):
            result.add("F-ACCOUNT", f"account edge {edge.get('id')} has no typed relation/witness", "B-PROVENANCE", outcomes)
            return False
        if not sources and relation != "INTRODUCE":
            result.add("F-ACCOUNT", "introduction lacks constructor/origin witness", "B-PROVENANCE", outcomes)
            return False
        if not sources:
            expected_witness = {
                "verifier": INTRODUCTION_VERIFIER,
                "constructor_ref": crossing.get("constructor_ref"),
                "target_ids": list(targets),
                "target_values": [destination_occurrences[item]["value"] for item in targets],
            }
            if witness != expected_witness:
                result.add("F-VERIFIER-OPEN", "introduction constructor witness is not executable", "B-PROVENANCE", outcomes)
                return False
        if not targets:
            allowed = set(case.get("demands", {}).get((destination_basis or {}).get("demand_ref"), {}).get("acceptable_losses", []))
            source_types = {source_occurrences[item].get("type") for item in sources if item in source_occurrences}
            if not witness or not source_types <= allowed or edge.get("residual") in (None, "", []):
                result.add("F-LOSS-OPEN", "terminal/loss edge is not permitted and residualized for this Demand", "B-RESOURCE", outcomes)
                return False
        allowed_losses = set(case.get("demands", {}).get((destination_basis or {}).get("demand_ref"), {}).get("acceptable_losses", []))
        if edge.get("loss") and (
            not isinstance(edge.get("loss"), list)
            or not set(edge["loss"]) <= allowed_losses
            or edge.get("residual") in (None, "", [])
        ):
            result.add("F-LOSS-OPEN", "partial loss is not accepted and residualized for this Demand", "B-RESOURCE", outcomes)
            return False
        if set(sources) & protected_sources and (
            not targets or relation in {"LOSS", "DISCHARGE"} or bool(edge.get("loss"))
        ):
            result.add("F-LOSS-OPEN", "a Demand-protected source occurrence is lost or residualized", "B-RESOURCE", outcomes)
            return False
        for item in sources:
            occurrence = source_occurrences.get(item, {})
            regime = source_regimes.get(item, {})
            policy = regime.get("resource_laws", {}).get(occurrence.get("type"))
            if policy not in RESOURCE_RULES:
                result.add("F-VERIFIER-OPEN", f"source occurrence {item} has no executable resource law", "B-RESOURCE", outcomes)
                return False
            if policy == "LINEAR" and relation not in {"TRANSFER", "DISCHARGE", "LOSS"}:
                result.add("F-RESOURCE", f"linear occurrence {item} uses an unauthorized transition", "B-RESOURCE", outcomes)
                return False
            if policy == "LINEAR" and ((relation == "TRANSFER" and len(targets) != 1) or (relation in {"DISCHARGE", "LOSS"} and targets)):
                result.add("F-RESOURCE", f"linear occurrence {item} is not consumed exactly once", "B-RESOURCE", outcomes)
                return False
            if policy == "AFFINE" and len(targets) > 1 and relation != "SPLIT":
                result.add("F-RESOURCE", f"affine occurrence {item} is duplicated", "B-RESOURCE", outcomes)
                return False
            if policy == "NONTRANSFERABLE" and targets:
                result.add("F-RESOURCE", f"nontransferable occurrence {item} crosses a boundary", "B-RESOURCE", outcomes)
                return False
            if occurrence.get("type") == "obligation":
                value = occurrence.get("value")
                if (
                    not isinstance(value, dict)
                    or any(not isinstance(value.get(field), str) or not value.get(field) for field in ("duty", "owner", "status"))
                ):
                    result.add("F-RESOURCE", f"obligation occurrence {item} lacks duty, owner, or status", "B-RESOURCE", outcomes)
                    return False
        correspondence_error = correspondence.get("error", 0) if isinstance(correspondence, dict) else 0
        if edge.get("error", 0) > correspondence_error or (edge.get("error", 0) > 0 and edge.get("residual") in (None, "", [])):
            result.add("F-LOSS-OPEN", f"account edge {edge.get('id')} exceeds or fails to residualize its Correspondence error", "B-RESOURCE", outcomes)
            return False
        if len(targets) > 1 and sources and relation not in {"SPLIT", "COPY_LICENSED"}:
            result.add("F-RESOURCE", f"one-to-many edge {edge.get('id')} has no executed split/copy relation", "B-RESOURCE", outcomes)
            return False
        if len(sources) > 1 and len(targets) == 1 and relation != "MERGE":
            result.add("F-RESOURCE", f"many-to-one edge {edge.get('id')} has no executed merge relation", "B-RESOURCE", outcomes)
            return False
        source_types = {source_occurrences.get(item, {}).get("type") for item in sources}
        target_types = {destination_occurrences.get(item, {}).get("type") for item in targets}
        if relation == "COPY_LICENSED":
            source_id = sources[0] if len(sources) == 1 else None
            source_occurrence = source_occurrences.get(source_id, {})
            source_policy = source_regimes.get(source_id, {}).get("resource_laws", {}).get(source_occurrence.get("type"))
            expected_witness = {
                "verifier": COPY_VERIFIER,
                "source": source_id,
                "targets": list(targets),
                "value_fingerprint": digest_object(source_occurrence.get("value"), "COPY-VALUE"),
                "target_lineages": [destination_occurrences.get(item, {}).get("lineage") for item in targets],
                "resource_license": "REUSABLE",
            }
            if witness.get("verifier") != COPY_VERIFIER:
                result.add("F-VERIFIER-OPEN", f"copy edge {edge.get('id')} names no executed verifier", "B-RESOURCE", outcomes)
                return False
            if (
                source_id is None
                or len(targets) < 2
                or source_policy != "REUSABLE"
                or source_types != target_types
                or any(destination_occurrences.get(item, {}).get("value") != source_occurrence.get("value") for item in targets)
                or any(destination_occurrences.get(item, {}).get("lineage") != f"{source_id}/via-copy" for item in targets)
                or witness != expected_witness
            ):
                result.add("F-RESOURCE", f"copy edge {edge.get('id')} lacks an exact reusable-value witness", "B-RESOURCE", outcomes)
                return False
        if relation == "SPLIT":
            source_id = sources[0] if len(sources) == 1 else None
            source_occurrence = source_occurrences.get(source_id, {})
            source_policy = source_regimes.get(source_id, {}).get("resource_laws", {}).get(source_occurrence.get("type"))
            source_value = source_occurrence.get("value")
            target_values = [destination_occurrences.get(item, {}).get("value") for item in targets]
            expected_witness = {
                "verifier": SPLIT_VERIFIER,
                "source": source_id,
                "targets": list(targets),
                "partition_fingerprint": digest_object(target_values, "SPLIT-PARTITION"),
                "target_lineages": [destination_occurrences.get(item, {}).get("lineage") for item in targets],
            }
            if witness.get("verifier") != SPLIT_VERIFIER:
                result.add("F-VERIFIER-OPEN", f"split edge {edge.get('id')} names no executed verifier", "B-RESOURCE", outcomes)
                return False
            if (
                source_id is None
                or len(targets) < 2
                or source_policy not in {"REUSABLE", "AFFINE"}
                or source_types != target_types
                or not isinstance(source_value, list)
                or any(not isinstance(value, list) for value in target_values)
                or [item for value in target_values for item in value] != source_value
                or [destination_occurrences.get(item, {}).get("lineage") for item in targets]
                != [f"{source_id}/part-{index + 1}" for index in range(len(targets))]
                or witness != expected_witness
            ):
                result.add("F-RESOURCE", f"split edge {edge.get('id')} lacks an exact partition witness", "B-RESOURCE", outcomes)
                return False
        if relation == "MERGE":
            target_id = targets[0] if len(targets) == 1 else None
            source_values = [source_occurrences.get(item, {}).get("value") for item in sources]
            target_value = destination_occurrences.get(target_id, {}).get("value")
            expected_witness = {
                "verifier": MERGE_VERIFIER,
                "sources": list(sources),
                "target": target_id,
                "inputs_fingerprint": digest_object(source_values, "MERGE-INPUTS"),
                "source_lineages": [source_occurrences.get(item, {}).get("lineage") for item in sources],
                "target_lineage": destination_occurrences.get(target_id, {}).get("lineage"),
            }
            if witness.get("verifier") != MERGE_VERIFIER:
                result.add("F-VERIFIER-OPEN", f"merge edge {edge.get('id')} names no executed verifier", "B-RESOURCE", outcomes)
                return False
            if (
                len(sources) < 2
                or target_id is None
                or source_types != target_types
                or any(not isinstance(value, list) for value in source_values)
                or target_value != [item for value in source_values for item in value]
                or destination_occurrences.get(target_id, {}).get("lineage") != "+".join(sources)
                or witness != expected_witness
            ):
                result.add("F-RESOURCE", f"merge edge {edge.get('id')} lacks an exact ordered merge witness", "B-RESOURCE", outcomes)
                return False
        semantic_edge = (
            not formation
            and sources
            and targets
            and (
                correspondence.get("source_type") in source_types
                or correspondence.get("destination_type") in target_types
            )
        )
        if semantic_edge:
            if relation not in {"TRANSLATE", "PRESERVE", "TRANSFORM"}:
                result.add("F-GUARANTEE", "claim-bearing edge uses no semantic relation", "B-PROVENANCE", outcomes)
                return False
            if len(sources) != 1 or len(targets) != 1:
                result.add("F-ACCOUNT", "reference semantic edge must relate one occurrence to one occurrence", "B-PROVENANCE", outcomes)
                return False
            source_value = source_occurrences.get(sources[0], {}).get("value")
            target_value = destination_occurrences.get(targets[0], {}).get("value")
            expected_witness = {
                "verifier": INSTANCE_VERIFIER,
                "correspondence_ref": correspondence.get("id"),
                "source": sources[0],
                "target": targets[0],
                "source_value": source_value,
                "target_value": target_value,
            }
            if (
                source_types != {correspondence.get("source_type")}
                or target_types != {correspondence.get("destination_type")}
                or source_value not in correspondence.get("domain", [])
                or correspondence.get("sentence_map", {}).get(source_value) != target_value
                or witness != expected_witness
            ):
                result.add("F-GUARANTEE", "semantic edge is not an instance of the verified Correspondence", "B-PROVENANCE", outcomes)
                return False
        if relation == "TRANSFER":
            if len(sources) != len(targets):
                result.add("F-RESOURCE", f"transfer edge {edge.get('id')} is not one-to-one", "B-RESOURCE", outcomes)
                return False
            for source_id, target_id in zip(sources, targets):
                source_value = source_occurrences.get(source_id, {}).get("value", {})
                target_value = destination_occurrences.get(target_id, {}).get("value", {})
                if (
                    source_occurrences.get(source_id, {}).get("type") != destination_occurrences.get(target_id, {}).get("type")
                    or not isinstance(source_value, dict)
                    or not isinstance(target_value, dict)
                    or source_value.get("owner") == target_value.get("owner")
                    or source_value.get("duty") != target_value.get("duty")
                    or source_value.get("status") != target_value.get("status")
                    or witness != {
                        "verifier": "linear-transfer-v1",
                        "source": source_id,
                        "target": target_id,
                        "accepted_by": target_value.get("owner"),
                    }
                ):
                    result.add("F-RESOURCE", f"transfer {source_id}->{target_id} lacks changed owner and acceptance", "B-RESOURCE", outcomes)
                    return False
    result.trace.append(f"account:{crossing.get('id')}:{len(edges)}-edges")
    result.offer_proof_artifact(
        "CrossingAccount",
        {
            "crossing_id": crossing.get("id"),
            "source_basis_refs": list(source_basis_ids),
            "destination_basis_ref": crossing.get("destination_basis_ref"),
            "produced_targets": list(produced_targets),
        },
        {"account_fingerprint": digest_object(edges, "ACCOUNT")},
    )
    return True


def has_unfounded_cycle(judgment: dict[str, Any]) -> bool:
    graph: dict[str, list[str]] = defaultdict(list)
    nodes: set[str] = set()
    for edge in judgment.get("support_edges", []):
        graph[edge["from"]].append(edge["to"])
        nodes.update((edge["from"], edge["to"]))
    foundations = set(judgment.get("foundations", []))
    reachable = set(foundations)
    queue = deque(foundations)
    while queue:
        node = queue.popleft()
        for target in graph.get(node, []):
            if target not in reachable:
                reachable.add(target)
                queue.append(target)
    required = set(judgment.get("premises", [])) | {judgment.get("id", "")}
    return bool(required - reachable)


def validate_judgment_and_standing(
    case: dict[str, Any], result: Evaluation, outcomes: dict[str, str], *, require_standing: bool | None = None
) -> bool:
    result.behaviors.update({"B-JUDGMENT", "B-GROUNDING"})
    judgment = case.get("judgment")
    if not isinstance(judgment, dict) or not judgment:
        result.add("F-JUDGMENT-OPEN", "destination Judgment is absent", "B-JUDGMENT", outcomes)
        return False
    judgment_required = {
        "id", "regime_ref", "demand_ref", "basis_ref", "claim", "rule", "premises",
        "witness", "result", "verifier_ref", "support_edges", "foundations", "dependencies", "validity",
    }
    judgment_validity = judgment.get("validity")
    if (
        not judgment_required <= set(judgment)
        or any(not isinstance(judgment.get(field), str) or not judgment.get(field) for field in ("id", "regime_ref", "demand_ref", "basis_ref", "claim", "rule", "result", "verifier_ref"))
        or not string_list(judgment.get("premises"), unique=True)
        or not string_list(judgment.get("foundations"), unique=True)
        or not string_list(judgment.get("dependencies"), unique=True)
        or not isinstance(judgment.get("witness"), dict)
        or not isinstance(judgment.get("support_edges"), list)
        or any(not isinstance(edge, dict) or not isinstance(edge.get("from"), str) or not isinstance(edge.get("to"), str) for edge in judgment.get("support_edges", []))
        or not isinstance(judgment_validity, list)
        or len(judgment_validity) != 2
        or any(not integer(item) for item in judgment_validity)
        or judgment_validity[0] > judgment_validity[1]
        or not (judgment_validity[0] <= case.get("at", -1) <= judgment_validity[1])
    ):
        result.add("F-JUDGMENT-OPEN", "destination Judgment lacks a mandatory typed field", "B-JUDGMENT", outcomes)
        return False
    basis = get_basis(case, judgment.get("basis_ref", ""))
    demand = case.get("demands", {}).get(judgment.get("demand_ref"))
    regime = case.get("regimes", {}).get(judgment.get("regime_ref"))
    if basis is None or demand is None or regime is None:
        result.add("F-INDEX", "Judgment has a dangling index", "B-JUDGMENT", outcomes)
        return False
    if basis.get("regime_ref") != judgment.get("regime_ref") or basis.get("demand_ref") != judgment.get("demand_ref"):
        result.add("F-INDEX", "Judgment is not destination-indexed", "B-JUDGMENT", outcomes)
        return False
    declared_judgment_verifier = regime.get("judgment_interfaces", {}).get(judgment.get("rule"))
    if (
        judgment.get("claim") not in regime.get("sentences", [])
        or declared_judgment_verifier != JUDGMENT_VERIFIER
        or judgment.get("verifier_ref") != declared_judgment_verifier
        or judgment.get("verifier_ref") not in basis.get("verifiers", [])
        or judgment_validity[0] < demand.get("horizon", [0, -1])[0]
        or judgment_validity[1] > demand.get("horizon", [0, -1])[1]
    ):
        result.add("F-JUDGMENT-OPEN", "Judgment claim or verifier is unavailable locally", "B-JUDGMENT", outcomes)
        return False
    if demand.get("return") != judgment.get("claim"):
        result.add("F-JUDGMENT-OPEN", "Judgment does not answer the exact demanded Return", "B-JUDGMENT", outcomes)
        return False
    basis_occurrences = occurrence_map(basis)
    premises = judgment.get("premises", [])
    expected_dependencies = closure_from(premises, basis.get("dependencies", []))
    if (
        not premises
        or not set(premises) <= set(basis_occurrences)
        or set(judgment.get("dependencies", [])) != expected_dependencies
    ):
        result.add("F-JUDGMENT-OPEN", "Judgment premises are absent from the current Basis or dependency disclosure", "B-JUDGMENT", outcomes)
        return False
    witness = judgment.get("witness", {})
    if judgment.get("rule") == "FINITE_SATISFACTION":
        port_types = {port.get("type") for port in regime.get("ports", {}).values()}
        claim_occurrence = witness.get("claim_occurrence")
        model_occurrence = witness.get("model_occurrence")
        claim_row = basis_occurrences.get(claim_occurrence, {})
        model_row = basis_occurrences.get(model_occurrence, {})
        if (
            set(premises) != {claim_occurrence, model_occurrence}
            or len(premises) != 2
            or claim_row.get("type") not in port_types
            or claim_row.get("value") != judgment.get("claim")
            or model_row.get("type") != "model"
            or model_row.get("value") != witness.get("model")
            or not satisfaction(regime, witness.get("model", ""), judgment["claim"])
            or judgment.get("result") != "SUPPORTED"
        ):
            result.add("F-JUDGMENT-OPEN", "finite local Judgment has no satisfying model witness", "B-JUDGMENT", outcomes)
            return False
    else:
        result.add("F-JUDGMENT-OPEN", f"local rule {judgment.get('rule')} has no executed reference verifier", "B-JUDGMENT", outcomes)
        return False
    expected_support_edges = {(premise, judgment.get("id")) for premise in premises}
    actual_support_edges = {(edge.get("from"), edge.get("to")) for edge in judgment.get("support_edges", [])}
    if len(judgment.get("support_edges", [])) != len(actual_support_edges) or actual_support_edges != expected_support_edges:
        result.add("F-GROUNDING", "finite Judgment support edges do not exactly connect its premises", "B-GROUNDING", outcomes)
        return False
    support_nodes = {endpoint for edge in judgment.get("support_edges", []) for endpoint in (edge.get("from"), edge.get("to"))}
    permitted_support_nodes = set(basis_occurrences) | {judgment.get("id")}
    if set(judgment.get("foundations", [])) != set(premises) or not support_nodes <= permitted_support_nodes:
        result.add("F-GROUNDING", "Judgment support graph contains an unbound node or foundation", "B-GROUNDING", outcomes)
        return False
    if judgment.get("fixed_point_witness") is not None:
        result.add("F-VERIFIER-OPEN", "the finite reference kernel has no executed fixed-point verifier", "B-GROUNDING", outcomes)
        return False
    if has_unfounded_cycle(judgment):
        result.add("F-GROUNDING", "Judgment support graph is not independently grounded", "B-GROUNDING", outcomes)
        return False
    result.trace.append(f"judge:{judgment['id']}:{judgment.get('result')}")
    result.offer_proof_artifact(
        "Judgment",
        {
            "judgment_id": judgment["id"],
            "result": judgment.get("result"),
            "claim": judgment.get("claim"),
            "demand_ref": judgment.get("demand_ref"),
        },
        {
            "basis_fingerprint": basis.get("fingerprint"),
            "verifier_ref": judgment.get("verifier_ref"),
        },
    )

    needs_standing = demand.get("required_standing") if require_standing is None else require_standing
    if not needs_standing:
        return True
    if demand.get("required_standing") is not True:
        result.add("F-INDEX", "Standing-producing operator conflicts with a Demand that does not require Standing", "B-INDEX", outcomes)
        return False
    result.behaviors.update({"B-STANDING", "B-AUTHORITY"})
    if regime.get("resource_laws", {}).get("authority") != "ATTENUATING":
        result.behaviors.add("B-RESOURCE")
        result.add("F-VERIFIER-OPEN", "destination Regime has no executable authority attenuation law", "B-AUTHORITY", outcomes)
        return False
    standing = case.get("standing")
    if not isinstance(standing, dict) or not standing:
        result.add("F-STANDING-OPEN", "Demand requires Standing but none is supplied", "B-STANDING", outcomes)
        return False
    standing_required = {
        "id", "regime_ref", "demand_ref", "basis_ref", "judgment_ref", "use", "policy_ref",
        "authority_chain", "limits", "validity", "dependencies", "verifier_ref", "witness",
    }
    validity = standing.get("validity")
    if (
        not standing_required <= set(standing)
        or any(not isinstance(standing.get(field), str) or not standing.get(field) for field in ("id", "regime_ref", "demand_ref", "basis_ref", "judgment_ref", "use", "policy_ref", "verifier_ref"))
        or not isinstance(standing.get("witness"), dict)
        or not string_list(standing.get("authority_chain"), unique=True)
        or not string_list(standing.get("dependencies"), unique=True)
        or not isinstance(standing.get("limits"), dict)
        or not isinstance(validity, list)
        or len(validity) != 2
        or any(not integer(item) for item in validity)
        or validity[0] > validity[1]
        or not (validity[0] <= case.get("at", 0) <= validity[1])
    ):
        result.add("F-STANDING-OPEN", "Standing lacks a complete typed validity/dependency contract", "B-STANDING", outcomes)
        return False
    if any(
        standing.get(field) != expected
        for field, expected in (
            ("regime_ref", judgment.get("regime_ref")),
            ("demand_ref", judgment.get("demand_ref")),
            ("basis_ref", judgment.get("basis_ref")),
            ("judgment_ref", judgment.get("id")),
            ("use", demand.get("use")),
        )
    ):
        result.add("F-INDEX", "Standing does not bind the exact destination Judgment index and use", "B-INDEX", outcomes)
        return False
    policy_spec = regime.get("policy_interfaces", {}).get(standing.get("policy_ref"))
    policy_occurrences = [
        row
        for row in basis.get("occurrences", [])
        if row.get("type") == "policy"
        and isinstance(row.get("value"), dict)
        and row["value"].get("id") == standing.get("policy_ref")
    ]
    if (
        standing.get("policy_ref") not in basis.get("policies", [])
        or not isinstance(policy_spec, dict)
        or len(policy_occurrences) != 1
        or policy_occurrences[0].get("value") != {"id": standing.get("policy_ref"), **policy_spec}
        or policy_spec.get("rule") != "ADMIT_SUPPORTED"
        or regime.get("admission_interfaces", {}).get(policy_spec.get("rule")) != ADMISSION_VERIFIER
        or standing.get("verifier_ref") != policy_spec.get("verifier")
        or standing.get("verifier_ref") not in basis.get("verifiers", [])
    ):
        result.add("F-STANDING-OPEN", "destination admission policy or verifier is absent", "B-STANDING", outcomes)
        return False
    authority_rows = basis.get("authorities", [])
    if not isinstance(authority_rows, list) or any(not isinstance(row, dict) for row in authority_rows):
        result.add("F-AUTHORITY", "Basis authority records are malformed", "B-AUTHORITY", outcomes)
        return False
    authority_ids = [row.get("id") for row in authority_rows]
    if any(not isinstance(item, str) or not item for item in authority_ids) or len(authority_ids) != len(set(authority_ids)):
        result.add("F-AUTHORITY", "Basis authority identity is missing or repeated", "B-AUTHORITY", outcomes)
        return False
    if any(
        "parent" not in row
        or "permissions" not in row
        or "uses" not in row
        or "validity" not in row
        or "revoked" not in row
        or
        (row.get("parent") is not None and not isinstance(row.get("parent"), str))
        or not string_list(row.get("permissions"), unique=True)
        or not string_list(row.get("uses"), unique=True)
        or not isinstance(row.get("validity"), list)
        or len(row.get("validity", [])) != 2
        or any(not integer(item) for item in row.get("validity", []))
        or row.get("validity", [1, 0])[0] > row.get("validity", [1, 0])[1]
        or not isinstance(row.get("revoked"), bool)
        for row in authority_rows
    ):
        result.add("F-AUTHORITY", "Basis authority record lacks a complete typed contract", "B-AUTHORITY", outcomes)
        return False
    authorities = {row["id"]: row for row in authority_rows}
    trusted_roots = set(basis.get("trusted_roots", []))
    chain = standing.get("authority_chain", [])
    if not chain:
        result.add("F-STANDING-OPEN", "Standing has no authority chain", "B-AUTHORITY", outcomes)
        return False
    authority_material = {
        row.get("value") for row in basis.get("occurrences", []) if row.get("type") == "authority"
    }
    if not set(chain) <= authority_material:
        result.add("F-AUTHORITY", "Standing authority chain is not materialized in the current Basis", "B-AUTHORITY", outcomes)
        return False
    previous: dict[str, Any] | None = None
    for authority_id in chain:
        authority = authorities.get(authority_id)
        if authority is None:
            result.add("F-AUTHORITY", f"missing authority {authority_id}", "B-AUTHORITY", outcomes)
            return False
        if authority.get("revoked") or not (authority.get("validity", [1, 0])[0] <= case.get("at", 0) <= authority.get("validity", [1, 0])[1]):
            result.add("F-AUTHORITY", f"authority {authority_id} is revoked or invalid", "B-AUTHORITY", outcomes)
            return False
        if previous is None:
            if authority_id not in trusted_roots or authority.get("parent") is not None:
                result.add("F-AUTHORITY", f"authority root {authority_id} is not configured", "B-AUTHORITY", outcomes)
                return False
        else:
            if authority.get("parent") != previous.get("id"):
                result.add("F-AUTHORITY", f"authority chain breaks at {authority_id}", "B-AUTHORITY", outcomes)
                return False
            if "DELEGATE" not in previous.get("permissions", []):
                result.add("F-AUTHORITY", f"authority {previous.get('id')} cannot delegate", "B-AUTHORITY", outcomes)
                return False
            parent_validity = previous.get("validity", [1, 0])
            child_validity = authority.get("validity", [1, 0])
            if child_validity[0] < parent_validity[0] or child_validity[1] > parent_validity[1]:
                result.add("F-AUTHORITY", f"authority {authority_id} expands validity", "B-AUTHORITY", outcomes)
                return False
            if not set(authority.get("permissions", [])) <= set(previous.get("permissions", [])):
                result.add("F-AUTHORITY", f"authority {authority_id} expands permission", "B-AUTHORITY", outcomes)
                return False
            if not set(authority.get("uses", [])) <= set(previous.get("uses", [])):
                result.add("F-AUTHORITY", f"authority {authority_id} expands use", "B-AUTHORITY", outcomes)
                return False
        previous = authority
    leaf = previous or {}
    if "ADMIT" not in leaf.get("permissions", []) or standing.get("use") not in leaf.get("uses", []):
        result.add("F-AUTHORITY", "authority leaf does not permit this admission/use", "B-AUTHORITY", outcomes)
        return False
    if validity[0] < leaf.get("validity", [1, 0])[0] or validity[1] > leaf.get("validity", [1, 0])[1]:
        result.add("F-STANDING-OPEN", "Standing validity exceeds its authority leaf", "B-STANDING", outcomes)
        return False
    policy_occurrence_id = policy_occurrences[0]["id"]
    authority_occurrence_ids = {
        row["id"]
        for row in basis.get("occurrences", [])
        if row.get("type") == "authority" and row.get("value") in set(chain)
    }
    required_dependencies = (
        set(judgment.get("dependencies", []))
        | {judgment["id"], basis["id"], demand["id"], standing["policy_ref"], policy_occurrence_id}
        | set(chain)
        | authority_occurrence_ids
    )
    if required_dependencies != set(standing.get("dependencies", [])):
        result.add("F-STANDING-OPEN", "Standing omits a result-changing Judgment, Basis, policy, or authority dependency", "B-STANDING", outcomes)
        return False
    limits = standing.get("limits", {})
    if (
        not limits
        or limits.get("claim") != judgment.get("claim")
        or limits.get("use") != demand.get("use")
        or not integer(limits.get("expires"))
        or limits["expires"] < case.get("at", 0)
        or limits["expires"] > leaf.get("validity", [0, -1])[1]
        or limits["expires"] > validity[1]
    ):
        result.add("F-STANDING-OPEN", "Standing decision witness or limits are absent", "B-STANDING", outcomes)
        return False
    expected_admission_witness = {
        "verifier": ADMISSION_VERIFIER,
        "policy_ref": standing.get("policy_ref"),
        "policy_version": policy_spec.get("version"),
        "rule": policy_spec.get("rule"),
        "judgment_ref": judgment.get("id"),
        "judgment_result": judgment.get("result"),
        "use": demand.get("use"),
        "at": case.get("at"),
        "authority_leaf": leaf.get("id"),
        "decision": "ADMIT",
    }
    if judgment.get("result") != "SUPPORTED" or standing.get("witness") != expected_admission_witness:
        result.add("F-STANDING-OPEN", "destination policy did not execute an exact admission decision", "B-STANDING", outcomes)
        return False
    result.trace.append(f"admit:{standing['id']}:{standing.get('use')}")
    result.offer_proof_artifact(
        "Standing",
        {
            "standing_id": standing["id"],
            "judgment_ref": standing.get("judgment_ref"),
            "use": standing.get("use"),
            "limits": copy.deepcopy(standing.get("limits")),
        },
        {"policy_ref": standing.get("policy_ref"), "authority_leaf": leaf.get("id")},
    )
    result.reverse = [
        f"standing:{standing['id']}",
        f"judgment:{judgment['id']}",
        f"authority:{'->'.join(chain)}",
        f"basis:{basis['id']}:{basis['fingerprint'][:12]}",
        f"demand:{demand['id']}",
    ]
    if case.get("correspondence"):
        result.reverse.append(f"correspondence:{case['correspondence']['id']}")
    if case.get("crossing"):
        result.reverse.append(f"crossing:{case['crossing']['id']}")
        result.reverse.extend(f"source:{item}" for item in case["crossing"].get("source_membrane", []))
    return True


def reject_standing_transport_preflight(
    case: dict[str, Any], result: Evaluation, outcomes: dict[str, str]
) -> bool:
    crossing = case.get("crossing", {})
    correspondence = case.get("correspondence")
    explicit_transformer = not case.get("formation") and isinstance(correspondence, dict) and (
        "standing_map" in correspondence or correspondence.get("transports_standing")
    )
    occurrence_transport = False
    if isinstance(crossing, dict):
        destination = get_basis(case, crossing.get("destination_basis_ref", ""))
        destination_occurrences = occurrence_map(destination or {})
        occurrence_transport = any(
            str(destination_occurrences.get(item, {}).get("type", "")).casefold() == "standing"
            for item in crossing.get("produced_targets", [])
        )
        for basis_id in crossing.get("source_basis_refs", []):
            source = get_basis(case, basis_id)
            source_occurrences = occurrence_map(source or {})
            occurrence_transport = occurrence_transport or any(
                str(source_occurrences.get(item, {}).get("type", "")).casefold() == "standing"
                for item in crossing.get("source_membrane", [])
            )
    if explicit_transformer or occurrence_transport:
        result.behaviors.update({"B-NOSTANDING", "B-TYPED", "B-OUTCOME"})
        result.add("F-STANDING-TRANSPORT", "Correspondence attempts to transport Standing", "B-NOSTANDING", outcomes)
        result.add("F-STANDING-TRANSPORT", "verified violation dominates unresolved prerequisites", "B-OUTCOME", outcomes)
        return True
    return False


def require_crossing_record(
    case: dict[str, Any], result: Evaluation, outcomes: dict[str, str]
) -> dict[str, Any] | None:
    crossing = case.get("crossing")
    if not isinstance(crossing, dict) or not CROSSING_FIELDS <= set(crossing):
        result.add("F-ACCOUNT", "Crossing omits a mandatory application/account field", "B-ACCOUNT", outcomes)
        return None
    return crossing


def evaluate_rebind(case: dict[str, Any], result: Evaluation, outcomes: dict[str, str]) -> None:
    if reject_standing_transport_preflight(case, result, outcomes):
        return
    crossing = require_crossing_record(case, result, outcomes)
    if crossing is None:
        return
    for basis_id in crossing.get("source_basis_refs", []):
        if not validate_basis(case, basis_id, result, outcomes):
            return
    if not validate_basis(case, crossing.get("destination_basis_ref", ""), result, outcomes):
        return
    if case.get("formation"):
        if crossing.get("source_basis_refs") or crossing.get("source_membrane"):
            result.add("F-ACCOUNT", "formation must have an empty source membrane", "B-ACCOUNT", outcomes)
            return
    else:
        if not validate_correspondence(case, result, outcomes):
            return
    if not validate_account(case, result, outcomes):
        return
    if not validate_judgment_and_standing(case, result, outcomes, require_standing=True):
        return
    standing = case["standing"]
    result.value = {
        "type": "Rebinding",
        "standing_id": standing["id"],
        "destination_basis_ref": crossing["destination_basis_ref"],
        "crossing_id": crossing["id"],
    }
    result.witness_bundle = {
        "forward": list(result.trace),
        "reverse": list(result.reverse),
        "destination_basis_fingerprint": case["bases"][crossing["destination_basis_ref"]]["fingerprint"],
    }


def evaluate_contextualize(case: dict[str, Any], result: Evaluation, outcomes: dict[str, str]) -> None:
    basis_id = case.get("basis_ref")
    if not isinstance(basis_id, str) or not validate_basis(case, basis_id, result, outcomes):
        return
    basis = case["bases"][basis_id]
    result.value = {
        "type": "Context",
        "basis_ref": basis_id,
        "membrane": sorted(basis["closure"]["members"]),
        "basis_fingerprint": basis["fingerprint"],
    }
    result.reverse = [
        f"context:{basis_id}",
        f"basis:{basis_id}:{basis['fingerprint'][:12]}",
        f"demand:{basis['demand_ref']}",
        f"regime:{basis['regime_ref']}:{basis['versions']['regime']}",
        *(f"occurrence:{item}" for item in sorted(basis["closure"]["members"])),
    ]
    result.witness_bundle = {
        "closure_checker": basis["closure"]["checker"],
        "forward": list(result.trace),
        "reverse": list(result.reverse),
    }


def evaluate_apply(case: dict[str, Any], result: Evaluation, outcomes: dict[str, str]) -> None:
    if reject_standing_transport_preflight(case, result, outcomes):
        return
    crossing = require_crossing_record(case, result, outcomes)
    if crossing is None:
        return
    for basis_id in crossing.get("source_basis_refs", []):
        if not validate_basis(case, basis_id, result, outcomes):
            return
    destination_basis_id = crossing.get("destination_basis_ref", "")
    if not validate_basis(case, destination_basis_id, result, outcomes):
        return
    if not case.get("formation") and not validate_correspondence(case, result, outcomes):
        return
    if not validate_account(case, result, outcomes):
        return
    result.value = {
        "type": "Crossing",
        "crossing_id": crossing["id"],
        "destination_basis_ref": destination_basis_id,
        "produced_targets": list(crossing.get("produced_targets", [])),
        "correspondence_ref": crossing.get("correspondence_ref"),
        "dependencies": list(crossing.get("dependencies", [])),
        "validity": list(crossing.get("validity", [])),
    }
    result.reverse = [
        f"crossing:{crossing['id']}",
        f"destination-basis:{destination_basis_id}",
        *(f"target:{item}" for item in reversed(crossing.get("produced_targets", []))),
        *(f"edge:{edge['id']}" for edge in reversed(crossing.get("account_edges", []))),
    ]
    if crossing.get("correspondence_ref"):
        result.reverse.append(f"correspondence:{crossing['correspondence_ref']}")
    result.reverse.extend(f"source-basis:{item}" for item in reversed(crossing.get("source_basis_refs", [])))
    result.reverse.extend(f"source:{item}" for item in reversed(crossing.get("source_membrane", [])))
    result.witness_bundle = {
        "account_fingerprint": digest_object(crossing.get("account_edges", []), "ACCOUNT"),
        "destination_basis_fingerprint": case["bases"][destination_basis_id]["fingerprint"],
        "forward": list(result.trace),
        "reverse": list(result.reverse),
    }


def evaluate_judge(case: dict[str, Any], result: Evaluation, outcomes: dict[str, str]) -> None:
    judgment = case.get("judgment", {})
    basis_id = judgment.get("basis_ref", "")
    if not validate_basis(case, basis_id, result, outcomes):
        return
    if not validate_judgment_and_standing(case, result, outcomes, require_standing=False):
        return
    result.reverse = [
        f"judgment:{judgment['id']}",
        f"basis:{basis_id}:{case['bases'][basis_id]['fingerprint'][:12]}",
        f"demand:{judgment['demand_ref']}",
        f"regime:{judgment['regime_ref']}",
        *(f"premise:{item}" for item in reversed(judgment.get("premises", []))),
    ]
    result.value = {"type": "Judgment", "judgment_id": judgment["id"], "result": judgment["result"], "claim": judgment["claim"]}
    result.witness_bundle = {
        "basis_fingerprint": case["bases"][basis_id]["fingerprint"],
        "forward": list(result.trace),
        "reverse": list(result.reverse),
    }


def evaluate_admit(case: dict[str, Any], result: Evaluation, outcomes: dict[str, str]) -> None:
    judgment = case.get("judgment", {})
    basis_id = judgment.get("basis_ref", "")
    if not validate_basis(case, basis_id, result, outcomes):
        return
    if not validate_judgment_and_standing(case, result, outcomes, require_standing=True):
        return
    standing = case["standing"]
    result.value = {"type": "Standing", "standing_id": standing["id"], "judgment_ref": standing["judgment_ref"], "limits": standing["limits"]}
    result.witness_bundle = {"reverse": list(result.reverse), "basis_fingerprint": case["bases"][basis_id]["fingerprint"]}


def evaluate_compose(case: dict[str, Any], result: Evaluation, outcomes: dict[str, str]) -> None:
    result.behaviors.update({"B-COMPOSE", "B-OUTCOME"})
    required_case_fields = {
        "at", "regimes", "composition_demand", "correspondences", "composite",
        "discharged_assumptions", "interaction_loss", "interaction_residual",
        "claims_path_independence",
    }
    if (
        not required_case_fields <= set(case)
        or not integer(case.get("at"))
        or not isinstance(case.get("claims_path_independence"), bool)
    ):
        result.add("F-COMPOSE-OPEN", "composition omits an explicit time, discharge, interaction, or path contract", "B-COMPOSE", outcomes)
        return
    chain = case.get("correspondences", [])
    if not isinstance(chain, list) or len(chain) != 2 or any(not isinstance(row, dict) for row in chain):
        result.add("F-COMPOSE-OPEN", "reference composition requires exactly two Correspondences", "B-COMPOSE", outcomes)
        return
    first, second = chain
    regimes = case.get("regimes")
    composition_demand = case.get("composition_demand")
    if (
        not isinstance(regimes, dict)
        or not isinstance(composition_demand, dict)
        or not isinstance(composition_demand.get("id"), str)
        or not isinstance(composition_demand.get("use"), str)
        or not string_list(composition_demand.get("accepted_assumptions"), unique=True)
        or not string_list(composition_demand.get("acceptable_losses"), unique=True)
        or not integer(composition_demand.get("max_error"))
        or composition_demand.get("max_error", -1) < 0
    ):
        result.add("F-COMPOSE-OPEN", "composition lacks its finite Regime and Demand contract", "B-COMPOSE", outcomes)
        return
    required = {
        "id", "source_regime", "source_version", "source_port", "source_type",
        "destination_regime", "destination_version", "destination_port", "destination_type",
        "domain", "sentence_map", "model_relation", "validity", "authority_scope", "guarantee",
        "assumptions", "loss", "residual", "resource_profile", "error_operator", "error",
        "verifier_ref", "destination_accepted",
    }
    string_fields = {
        "id", "source_regime", "source_version", "source_port", "source_type",
        "destination_regime", "destination_version", "destination_port", "destination_type",
        "guarantee", "resource_profile", "error_operator", "verifier_ref",
    }
    for correspondence in chain:
        validity = correspondence.get("validity")
        if (
            not required <= set(correspondence)
            or any(not isinstance(correspondence.get(field), str) or not correspondence.get(field) for field in string_fields)
            or not string_list(correspondence.get("domain"), unique=True)
            or not correspondence.get("domain")
            or not isinstance(correspondence.get("sentence_map"), dict)
            or not isinstance(correspondence.get("model_relation"), list)
            or any(not isinstance(pair, list) or len(pair) != 2 or not all(isinstance(item, str) and item for item in pair) for pair in correspondence.get("model_relation", []))
            or not isinstance(validity, list)
            or len(validity) != 2
            or any(not integer(item) for item in validity)
            or validity[0] > validity[1]
            or not string_list(correspondence.get("authority_scope"), unique=True)
            or not string_list(correspondence.get("assumptions"), unique=True)
            or not string_list(correspondence.get("loss"))
            or not string_list(correspondence.get("residual"))
            or not integer(correspondence.get("error"))
            or correspondence["error"] < 0
            or correspondence.get("verifier_ref") != CORRESPONDENCE_VERIFIER
            or correspondence.get("destination_accepted") is not True
        ):
            result.add("F-COMPOSE-OPEN", "a composition hop lacks a mandatory verified Correspondence field", "B-COMPOSE", outcomes)
            return
        if correspondence.get("loss") and not correspondence.get("residual"):
            result.add("F-COMPOSE-OPEN", "a lossy composition hop has no residual", "B-COMPOSE", outcomes)
            return
        source_regime = regimes.get(correspondence.get("source_regime"))
        destination_regime = regimes.get(correspondence.get("destination_regime"))
        if (
            not valid_regime_shape(source_regime)
            or not executable_regime_shape(source_regime)
            or not valid_regime_shape(destination_regime)
            or not executable_regime_shape(destination_regime)
            or "COMPOSE" not in source_regime.get("capabilities", [])
            or "COMPOSE" not in destination_regime.get("capabilities", [])
            or correspondence.get("source_version") != source_regime.get("version")
            or correspondence.get("destination_version") != destination_regime.get("version")
            or source_regime.get("ports", {}).get(correspondence.get("source_port"), {}).get("type") != correspondence.get("source_type")
            or destination_regime.get("ports", {}).get(correspondence.get("destination_port"), {}).get("type") != correspondence.get("destination_type")
            or correspondence.get("verifier_ref") not in destination_regime.get("verifier_interfaces", [])
        ):
            result.add("F-COMPOSE-OPEN", "a composition hop is not typed and verified by its endpoint Regimes", "B-COMPOSE", outcomes)
            return
        domain = correspondence.get("domain", [])
        mapping = correspondence.get("sentence_map", {})
        model_relation = correspondence.get("model_relation", [])
        if (
            set(mapping) != set(domain)
            or any(item not in source_regime.get("sentences", []) for item in domain)
            or any(mapping.get(item) not in destination_regime.get("sentences", []) for item in domain)
            or not model_relation
            or any(
                not isinstance(pair, list)
                or len(pair) != 2
                or pair[0] not in source_regime.get("models", [])
                or pair[1] not in destination_regime.get("models", [])
                for pair in model_relation
            )
        ):
            result.add("F-COMPOSE-OPEN", "a composition hop has no executable finite semantic relation", "B-COMPOSE", outcomes)
            return
        if any(
            not any(satisfaction(source_regime, model, sentence) for model in source_regime.get("models", []))
            for sentence in domain
        ):
            result.add("F-COMPOSE-OPEN", "a composition hop domain is vacuous in its finite source Regime", "B-COMPOSE", outcomes)
            return
        guarantee = correspondence.get("guarantee")
        if guarantee not in {"PRESERVES", "REFLECTS", "EXACT"}:
            result.add("F-COMPOSE-OPEN", "the finite composition profile does not implement this guarantee", "B-COMPOSE", outcomes)
            return
        for source_model, destination_model in model_relation:
            for sentence in domain:
                source_true = satisfaction(source_regime, source_model, sentence)
                destination_true = satisfaction(destination_regime, destination_model, mapping[sentence])
                if guarantee in {"PRESERVES", "EXACT"} and source_true and not destination_true:
                    result.add("F-COMPOSE-OPEN", "a hop's preservation guarantee has a finite countermodel", "B-COMPOSE", outcomes)
                    return
                if guarantee in {"REFLECTS", "EXACT"} and destination_true and not source_true:
                    result.add("F-COMPOSE-OPEN", "a hop's reflection guarantee has a finite countermodel", "B-COMPOSE", outcomes)
                    return
        if correspondence.get("error") != 0:
            result.add("F-COMPOSE-OPEN", "exact/preservation composition cannot carry an unverified numeric error", "B-COMPOSE", outcomes)
            return
    result.offer_proof_artifact(
        "CorrespondenceChainPrefix",
        {
            "hop_ids": [first["id"], second["id"]],
            "status": "HOPS_INDIVIDUALLY_VERIFIED_COMPOSITION_NOT_YET_EARNED",
        },
        {"hop_fingerprints": [digest_object(first, "CORRESPONDENCE"), digest_object(second, "CORRESPONDENCE")]},
    )
    if first.get("destination_regime") != second.get("source_regime") or first.get("destination_version") != second.get("source_version"):
        result.add("F-COMPOSE-OPEN", "intermediate Regime/version does not align", "B-COMPOSE", outcomes)
        return
    if (
        first.get("destination_port") != second.get("source_port")
        or first.get("destination_type") != second.get("source_type")
        or not first.get("destination_port")
    ):
        result.add("F-COMPOSE-OPEN", "intermediate port/type does not align", "B-COMPOSE", outcomes)
        return
    first_range = set(first.get("sentence_map", {}).values())
    second_domain = set(second.get("domain", []))
    if not first_range <= second_domain:
        result.add("F-COMPOSE-OPEN", "first range is outside second domain", "B-COMPOSE", outcomes)
        return
    at = case.get("at", 0)
    if any(not (row.get("validity", [1, 0])[0] <= at <= row.get("validity", [1, 0])[1]) for row in chain):
        result.add("F-COMPOSE-OPEN", "composition validity intervals do not cover the operation", "B-COMPOSE", outcomes)
        return
    if not set(case.get("composite", {}).get("authority_scope", [])) <= (
        set(first.get("authority_scope", [])) & set(second.get("authority_scope", []))
    ):
        result.add("F-COMPOSE-OPEN", "composite authority does not attenuate by intersection", "B-COMPOSE", outcomes)
        return
    if first.get("resource_profile") != second.get("resource_profile") or not first.get("resource_profile"):
        result.add("F-COMPOSE-OPEN", "resource transition profiles do not compose", "B-COMPOSE", outcomes)
        return
    error_operator = first.get("error_operator")
    if error_operator != second.get("error_operator") or error_operator not in {"SUM", "MAX"}:
        result.add("F-COMPOSE-OPEN", "error operators are missing or incompatible", "B-COMPOSE", outcomes)
        return
    expected_error = (
        first.get("error", 0) + second.get("error", 0)
        if error_operator == "SUM"
        else max(first.get("error", 0), second.get("error", 0))
    )
    composite = case.get("composite", {})
    if (
        not isinstance(composite, dict)
        or not isinstance(composite.get("id"), str)
        or not composite.get("id")
        or not string_list(composite.get("authority_scope"), unique=True)
    ):
        result.add("F-COMPOSE-OPEN", "composite Correspondence is not a typed record", "B-COMPOSE", outcomes)
        return
    if composite.get("error") != expected_error or not integer(composite.get("error")) or composite.get("error", -1) < 0:
        result.add("F-COMPOSE-OPEN", "composite error does not use the declared additive operator", "B-COMPOSE", outcomes)
        return
    guarantee_product = {
        ("EXACT", "EXACT"): "EXACT",
        ("EXACT", "PRESERVES"): "PRESERVES",
        ("PRESERVES", "EXACT"): "PRESERVES",
        ("PRESERVES", "PRESERVES"): "PRESERVES",
        ("EXACT", "REFLECTS"): "REFLECTS",
        ("REFLECTS", "EXACT"): "REFLECTS",
        ("REFLECTS", "REFLECTS"): "REFLECTS",
    }
    expected_guarantee = guarantee_product.get((first.get("guarantee"), second.get("guarantee")))
    if expected_guarantee is None or composite.get("guarantee") != expected_guarantee:
        result.add("F-COMPOSE-OPEN", "composite guarantee is unclosed or stronger than its hops", "B-COMPOSE", outcomes)
        return
    discharges = case.get("discharged_assumptions", {})
    if not isinstance(discharges, dict):
        result.add("F-COMPOSE-OPEN", "assumption discharge is not a witnessed mapping", "B-COMPOSE", outcomes)
        return
    available_assumptions = set(first.get("assumptions", [])) | set(second.get("assumptions", []))
    for assumption, witness in discharges.items():
        if (
            assumption not in available_assumptions
            or not isinstance(witness, dict)
            or witness.get("verifier_ref") != COMPOSITION_VERIFIER
            or witness.get("assumption") != assumption
            or not isinstance(witness.get("evidence"), str)
            or not witness.get("evidence")
        ):
            result.add("F-COMPOSE-OPEN", f"assumption {assumption} lacks an executed discharge witness", "B-COMPOSE", outcomes)
            return
    discharged = set(discharges)
    expected_assumptions = (set(first.get("assumptions", [])) | set(second.get("assumptions", []))) - discharged
    if not expected_assumptions <= set(composition_demand.get("accepted_assumptions", [])):
        result.add("F-COMPOSE-OPEN", "remaining hop assumptions are outside the composition Demand", "B-COMPOSE", outcomes)
        return
    if set(composite.get("assumptions", [])) != expected_assumptions:
        result.add("F-COMPOSE-OPEN", "composite assumptions disappear or appear without discharge", "B-COMPOSE", outcomes)
        return
    interaction_loss = case.get("interaction_loss", [])
    interaction_residual = case.get("interaction_residual", [])
    if not string_list(interaction_loss) or not string_list(interaction_residual):
        result.add("F-COMPOSE-OPEN", "interaction loss or residual is malformed", "B-COMPOSE", outcomes)
        return
    expected_loss = first.get("loss", []) + second.get("loss", []) + interaction_loss
    if not set(expected_loss) <= set(composition_demand.get("acceptable_losses", [])):
        result.add("F-COMPOSE-OPEN", "composite loss is outside the composition Demand", "B-COMPOSE", outcomes)
        return
    if composite.get("loss", []) != expected_loss:
        result.add("F-COMPOSE-OPEN", "composite loss does not accumulate hop and interaction loss", "B-COMPOSE", outcomes)
        return
    expected_residual = first.get("residual", []) + second.get("residual", []) + interaction_residual
    if composite.get("residual") != expected_residual or (expected_loss and not expected_residual):
        result.add("F-COMPOSE-OPEN", "composite residual does not preserve every lossy remainder", "B-COMPOSE", outcomes)
        return
    expected_map = {key: second["sentence_map"][value] for key, value in first.get("sentence_map", {}).items() if value in second.get("sentence_map", {})}
    if case.get("composite", {}).get("sentence_map") != expected_map:
        result.add("F-COMPOSE-OPEN", "composite sentence map differs from sequential application", "B-COMPOSE", outcomes)
        return
    expected_relation = sorted(
        {
            (left[0], right[1])
            for left in first.get("model_relation", [])
            for right in second.get("model_relation", [])
            if left[1] == right[0]
        }
    )
    expected_model_relation = [list(pair) for pair in expected_relation]
    if not expected_model_relation or composite.get("model_relation") != expected_model_relation:
        result.add("F-COMPOSE-OPEN", "composite related-model relation differs from relational composition", "B-COMPOSE", outcomes)
        return
    expected_validity = [max(first["validity"][0], second["validity"][0]), min(first["validity"][1], second["validity"][1])]
    expected_fields = {
        "source_regime": first["source_regime"],
        "source_version": first["source_version"],
        "source_port": first["source_port"],
        "source_type": first["source_type"],
        "destination_regime": second["destination_regime"],
        "destination_version": second["destination_version"],
        "destination_port": second["destination_port"],
        "destination_type": second["destination_type"],
        "domain": first["domain"],
        "validity": expected_validity,
        "verifier_ref": COMPOSITION_VERIFIER,
        "destination_accepted": True,
        "resource_profile": first["resource_profile"],
        "error_operator": error_operator,
    }
    if any(composite.get(field) != value for field, value in expected_fields.items()):
        result.add("F-COMPOSE-OPEN", "composite Correspondence omits or changes a derived endpoint, domain, validity, verifier, or resource field", "B-COMPOSE", outcomes)
        return
    if expected_error > composition_demand.get("max_error", -1):
        result.add("F-COMPOSE-OPEN", "composite error exceeds the composition Demand", "B-COMPOSE", outcomes)
        return
    if case.get("claims_path_independence"):
        alternate_map = case.get("alternative_sentence_map")
        coherence = case.get("coherence_witness")
        if (
            not isinstance(alternate_map, dict)
            or alternate_map != expected_map
            or not isinstance(coherence, dict)
            or coherence.get("verifier_ref") != "finite-map-equality-v1"
            or coherence.get("left") != digest_object(expected_map, "COMPOSED-MAP")
            or coherence.get("right") != digest_object(alternate_map, "COMPOSED-MAP")
        ):
            result.add("F-COMPOSE-OPEN", "path independence lacks an executed finite-map coherence witness", "B-COMPOSE", outcomes)
            return
    result.trace.append(f"compose:{first['id']}+{second['id']}")
    result.offer_proof_artifact(
        "CompositeCorrespondence",
        {
            "id": composite.get("id"),
            "hops": [first["id"], second["id"]],
            "guarantee": expected_guarantee,
            "error": expected_error,
        },
        {"verifier_ref": COMPOSITION_VERIFIER, "map_fingerprint": digest_object(expected_map, "COMPOSED-MAP")},
    )
    result.reverse = [f"composite:{case.get('composite', {}).get('id')}", f"hop:{second['id']}", f"hop:{first['id']}"]
    result.value = {
        "type": "Correspondence",
        "id": composite.get("id"),
        **copy.deepcopy(expected_fields),
        "sentence_map": copy.deepcopy(expected_map),
        "model_relation": copy.deepcopy(expected_model_relation),
        "authority_scope": copy.deepcopy(composite["authority_scope"]),
        "guarantee": expected_guarantee,
        "assumptions": sorted(expected_assumptions),
        "loss": copy.deepcopy(expected_loss),
        "residual": copy.deepcopy(expected_residual),
        "error": expected_error,
    }
    result.witness_bundle = {
        "verifier_ref": COMPOSITION_VERIFIER,
        "hops": [first["id"], second["id"]],
        "input_fingerprint": digest_object(
            {"regimes": regimes, "demand": composition_demand, "hops": chain}, "COMPOSITION-INPUT"
        ),
        "coherence": case.get("coherence_witness"),
        "reverse": list(result.reverse),
    }


def leaf_pointer_set(value: Any, prefix: str = "") -> set[str]:
    if isinstance(value, dict):
        pointers: set[str] = set()
        for key, item in value.items():
            escaped = key.replace("~", "~0").replace("/", "~1")
            pointers |= leaf_pointer_set(item, f"{prefix}/{escaped}")
        return pointers or {prefix or "/"}
    if isinstance(value, list):
        pointers = set()
        for index, item in enumerate(value):
            pointers |= leaf_pointer_set(item, f"{prefix}/{index}")
        return pointers or {prefix or "/"}
    return {prefix or "/"}


def evaluate_reassess(case: dict[str, Any], result: Evaluation, outcomes: dict[str, str]) -> None:
    result.behaviors.update({"B-REASSESS", "B-OUTCOME", "B-BASIS"})
    old_basis = case.get("old_basis")
    new_basis = case.get("new_basis")
    dependencies = case.get("result_dependencies")
    old_result = case.get("old_result")
    at = case.get("at")
    if (
        not isinstance(old_basis, dict)
        or not isinstance(new_basis, dict)
        or not isinstance(old_result, dict)
        or not integer(at)
        or case.get("dependency_interface") != "all-leaves-v1"
        or not string_list(dependencies, unique=True)
        or not dependencies
        or any(not dependency.startswith("/") for dependency in dependencies)
    ):
        result.add("F-REASSESS-OPEN", "reassessment lacks typed JSON-Pointer dependencies or Basis snapshots", "B-REASSESS", outcomes)
        return
    all_leaf_paths = leaf_pointer_set(old_basis) | leaf_pointer_set(new_basis)
    old_validity = old_result.get("validity")
    if (
        set(dependencies) != all_leaf_paths
        or old_result.get("type") not in {"Judgment", "Standing"}
        or not isinstance(old_result.get("id"), str)
        or not old_result.get("id")
        or old_result.get("dependency_interface") != "all-leaves-v1"
        or set(old_result.get("dependencies", [])) != all_leaf_paths
        or old_result.get("basis_fingerprint") != digest_object(old_basis, "REASSESS-BASIS")
        or not isinstance(old_validity, list)
        or len(old_validity) != 2
        or any(not integer(item) for item in old_validity)
        or not (old_validity[0] <= at <= old_validity[1])
    ):
        result.add("F-REASSESS-OPEN", "result dependency certificate is incomplete, stale, or invalid", "B-REASSESS", outcomes)
        return
    witnesses = case.get("equivalence_witnesses", {})
    if "equivalence_witnesses" not in case or not isinstance(witnesses, dict):
        result.add("F-REASSESS-OPEN", "equivalence witness set is malformed", "B-REASSESS", outcomes)
        return
    sentinel = object()
    affected: set[str] = set()
    for dependency in dependencies:
        old_value = pointer_get(old_basis, dependency, sentinel)
        new_value = pointer_get(new_basis, dependency, sentinel)
        if old_value is sentinel or new_value is sentinel or old_value != new_value:
            affected.add(dependency)
    result.offer_proof_artifact(
        "DependencyDelta",
        {
            "old_result_ref": old_result["id"],
            "affected_dependencies": sorted(affected),
            "current_status": "NOT_YET_REEARNED",
        },
        {
            "old_basis_fingerprint": old_result["basis_fingerprint"],
            "new_basis_fingerprint": digest_object(new_basis, "REASSESS-BASIS"),
            "dependency_interface": "all-leaves-v1",
        },
    )
    unproved: set[str] = set()
    unknown_verifier: set[str] = set()
    declared_verifiers = set(case.get("verifier_interfaces", [])) if isinstance(case.get("verifier_interfaces", []), list) else set()
    if "all-leaves-v1" not in declared_verifiers:
        result.add("F-VERIFIER-OPEN", "reassessment lacks its executable full-leaf dependency interface", "B-REASSESS", outcomes)
        return
    for dependency in affected:
        witness = witnesses.get(dependency)
        if not isinstance(witness, dict) or not witness:
            unproved.add(dependency)
            continue
        verifier = witness.get("verifier")
        if verifier != "casefold-text-v1" or verifier not in declared_verifiers:
            unknown_verifier.add(dependency)
            continue
        old_value = pointer_get(old_basis, dependency, sentinel)
        new_value = pointer_get(new_basis, dependency, sentinel)
        if old_value is sentinel or new_value is sentinel:
            unproved.add(dependency)
            continue
        executable_equivalence = (
            isinstance(old_value, str)
            and isinstance(new_value, str)
            and old_value.casefold() == new_value.casefold()
        )
        if (
            not executable_equivalence
            or witness.get("old") != digest_object(old_value, "DEPENDENCY")
            or witness.get("new") != digest_object(new_value, "DEPENDENCY")
            or witness.get("relation") != "EQUIVALENT_FOR_DEMAND"
        ):
            unproved.add(dependency)
    if unknown_verifier:
        result.add("F-VERIFIER-OPEN", f"reassessment names no executed equivalence verifier: {sorted(unknown_verifier)}", "B-REASSESS", outcomes)
        return
    if unproved:
        result.add("F-REASSESS-OPEN", f"changed dependencies lack executable equivalence: {sorted(unproved)}", "B-REASSESS", outcomes)
        return
    changed_leaves = {
        path
        for path in all_leaf_paths
        if pointer_get(old_basis, path, sentinel) != pointer_get(new_basis, path, sentinel)
    }
    covered_changes = {
        path
        for path in changed_leaves
        if any(path == dependency or path.startswith(dependency + "/") or dependency.startswith(path + "/") for dependency in affected)
    }
    irrelevant = changed_leaves - covered_changes
    if irrelevant:
        result.add("F-REASSESS-OPEN", f"changed leaves escaped certified dependency coverage: {sorted(irrelevant)}", "B-REASSESS", outcomes)
        return
    result.trace.append(f"reassess:lawful-no-op:{','.join(sorted(affected)) or 'no-change'}")
    result.offer_proof_artifact(
        "Reassessment",
        {
            "old_result_ref": old_result["id"],
            "affected_dependencies": sorted(affected),
            "disposition": "LAWFUL_NO_OP",
        },
        {"dependency_interface": "all-leaves-v1", "witness_refs": sorted(witnesses)},
    )
    result.reverse = [
        f"new-basis:{digest_object(new_basis, 'REASSESS-BASIS')[:12]}",
        "equivalence-witnesses",
        f"old-result:{old_result['id']}",
        "old-result-dependencies",
        f"old-basis:{old_result['basis_fingerprint'][:12]}",
    ]
    result.value = {
        "type": "Reassessment",
        "disposition": "LAWFUL_NO_OP",
        "proved_equivalent": sorted(affected),
        "dependency_interface": "all-leaves-v1",
        "new_basis_fingerprint": digest_object(new_basis, "REASSESS-BASIS"),
    }
    result.witness_bundle = {
        "equivalence_witnesses": sorted(witnesses),
        "forward": list(result.trace),
        "reverse": list(result.reverse),
    }


WORLD_STAGES = ["AUTHORIZED", "ATTEMPTED", "EXECUTED", "OCCURRED", "OBSERVED", "ATTRIBUTED", "DURABLE"]


def evaluate_effect(case: dict[str, Any], result: Evaluation, outcomes: dict[str, str]) -> None:
    result.behaviors.update({"B-EFFECT", "B-OUTCOME"})
    effect = case.get("effect", {})
    if not isinstance(effect, dict):
        result.add("F-EFFECT", "effect profile is not a typed record", "B-EFFECT", outcomes)
        return
    records = effect.get("records", [])
    if not isinstance(records, list) or not records or any(not isinstance(record, dict) for record in records):
        result.add("F-EFFECT", "effect claim has no typed event records", "B-EFFECT", outcomes)
        return
    last = -1
    last_time = -1
    record_ids: set[str] = set()
    basis_snapshots = effect.get("basis_snapshots", {})
    proposition = effect.get("proposition")
    correlation = effect.get("correlation_id")
    if (
        not isinstance(basis_snapshots, dict)
        or not isinstance(proposition, str)
        or not proposition
        or not isinstance(correlation, str)
        or not correlation
    ):
        result.add("F-EFFECT", "effect profile lacks a typed proposition, correlation, or Basis map", "B-EFFECT", outcomes)
        return
    if not isinstance(effect.get("claims_atomicity"), bool) or not isinstance(effect.get("claims_exactly_once"), bool):
        result.add("F-EFFECT", "effect profile must state explicit atomicity and exactly-once nonclaims/claims", "B-EFFECT", outcomes)
        return
    for record in records:
        if record.get("stage") not in WORLD_STAGES or WORLD_STAGES.index(record["stage"]) <= last:
            result.add("F-EFFECT", "world/protocol stages are missing, unknown, or out of order", "B-EFFECT", outcomes)
            return
        last = WORLD_STAGES.index(record["stage"])
        snapshot = basis_snapshots.get(record.get("basis_ref"))
        if (
            not isinstance(record.get("id"), str)
            or not record.get("id")
            or record["id"] in record_ids
            or not isinstance(record.get("basis_ref"), str)
            or not record.get("basis_ref")
            or record.get("basis_ref") not in basis_snapshots
            or not isinstance(record.get("witness"), str)
            or not record.get("witness")
            or not integer(record.get("at"))
            or record["at"] < last_time
            or not isinstance(snapshot, dict)
            or snapshot.get("state") != record.get("stage")
            or not integer(snapshot.get("at"))
            or snapshot["at"] > record["at"]
            or snapshot.get("proposition") != proposition
            or snapshot.get("correlation_id") != correlation
            or snapshot.get("witness") != record.get("witness")
        ):
            result.add("F-EFFECT", "effect record lacks unique identity, Basis, witness, or valid ordering", "B-EFFECT", outcomes)
            return
        record_ids.add(record["id"])
        last_time = record["at"]
        if record.get("proposition") != proposition or record.get("correlation_id") != correlation:
            result.add("F-EFFECT", "effect record is unrelated to the exact proposition/correlation", "B-EFFECT", outcomes)
            return
    if not string_list(effect.get("claims"), unique=True):
        result.add("F-EFFECT", "effect claims are not a unique typed stage list", "B-EFFECT", outcomes)
        return
    claims = set(effect.get("claims", []))
    if not claims <= set(WORLD_STAGES):
        result.add("F-EFFECT", "effect claim names an unknown world/protocol stage", "B-EFFECT", outcomes)
        return
    observed_stages = {record.get("stage") for record in records}
    if claims != observed_stages:
        result.add("F-EFFECT", "effect claims and typed stage records are not the same exact set", "B-EFFECT", outcomes)
        return
    highest_claim = max((WORLD_STAGES.index(stage) for stage in claims), default=-1)
    required_prefix = WORLD_STAGES[: highest_claim + 1]
    actual_stages = [record.get("stage") for record in records]
    if actual_stages != required_prefix:
        result.add("F-EFFECT", "action-stage claim lacks its complete typed predecessor trace", "B-EFFECT", outcomes)
        return
    result.trace.extend(f"effect:{row['stage']}" for row in records)
    result.offer_proof_artifact(
        "EffectTrace",
        {
            "proposition": proposition,
            "certified_stages": actual_stages,
            "external_actuality": "NOT_CLAIMED",
        },
        {"record_ids": [row["id"] for row in records], "provider_witness": effect.get("provider_witness")},
    )
    if effect.get("claims_atomicity"):
        result.add("F-ATOMICITY-OPEN", "the core has no storage-provider verifier for an atomicity claim", "B-EFFECT", outcomes)
        return
    if effect.get("claims_exactly_once"):
        result.add("F-ATOMICITY-OPEN", "the core has no external effect-domain verifier for exactly-once", "B-EFFECT", outcomes)
        return
    result.reverse = [f"effect-claim:{stage}" for stage in reversed(sorted(claims, key=WORLD_STAGES.index))]
    result.value = {"type": "EffectTraceCertificate", "proposition": proposition, "certified_stages": actual_stages, "external_actuality": "NOT_CLAIMED"}
    result.witness_bundle = {"record_ids": [row["id"] for row in records], "provider_witness": effect.get("provider_witness"), "reverse": list(result.reverse)}


def evaluate_projection(case: dict[str, Any], result: Evaluation, outcomes: dict[str, str]) -> None:
    result.behaviors.update({"B-PROJECTION", "B-OUTCOME"})
    profile = case.get("projection", {})
    states = profile.get("states", [])
    demand_states = profile.get("demand_states", [])
    projection_map = profile.get("projection_map", {})
    reconstruction_map = profile.get("reconstruction_map", {})
    query_table = profile.get("query_table", {})
    mode = profile.get("mode")
    projection_kind = profile.get("kind", "PROJECTION")
    bound = profile.get("bound", 0)
    residual = profile.get("residual")
    if (
        not string_list(states, unique=True)
        or not states
        or not string_list(demand_states, unique=True)
        or states != demand_states
        or mode not in {"EXACT", "BOUNDED"}
        or projection_kind not in {"PROJECTION", "COMPRESSION"}
        or "bound" not in profile
        or not integer(bound)
        or bound < 0
        or not isinstance(projection_map, dict)
        or not isinstance(reconstruction_map, dict)
        or not isinstance(query_table, dict)
        or not isinstance(residual, list)
        or any(not isinstance(row, dict) for row in residual)
    ):
        result.add("F-PROJECTION", "projection profile is incomplete or ill typed", "B-PROJECTION", outcomes)
        return
    expected_residual: list[dict[str, Any]] = []
    for state in states:
        view = projection_map.get(state)
        reconstructed_state = reconstruction_map.get(view)
        if (
            state not in projection_map
            or view not in reconstruction_map
            or reconstructed_state not in states
            or state not in query_table
            or reconstructed_state not in query_table
        ):
            result.add("F-PROJECTION", f"projection lacks executable reconstruction/query for {state}", "B-PROJECTION", outcomes)
            return
        source_value = query_table[state]
        destination_value = query_table[reconstructed_state]
        difference = abs(source_value - destination_value) if integer(source_value) and integer(destination_value) else (0 if source_value == destination_value and type(source_value) is type(destination_value) else 1)
        if mode == "EXACT" and difference != 0:
            result.add("F-PROJECTION", f"projection changes demanded Return at {state}", "B-PROJECTION", outcomes)
            return
        if mode == "BOUNDED" and difference > bound:
            result.add("F-PROJECTION", f"compression exceeds bound at {state}", "B-PROJECTION", outcomes)
            return
        if difference:
            expected_residual.append(
                {
                    "state": state,
                    "source_return": source_value,
                    "reconstructed_state": reconstructed_state,
                    "reconstructed_return": destination_value,
                    "difference": difference,
                }
            )
    result.offer_proof_artifact(
        "CompressionComparison" if projection_kind == "COMPRESSION" else "ProjectionComparison",
        {
            "mode": mode,
            "states_checked": len(states),
            "bound": bound,
            "residual": copy.deepcopy(expected_residual),
        },
        {"projection_fingerprint": digest_object(projection_map, "PROJECTION")},
    )
    if mode == "EXACT" and (bound != 0 or residual != []):
        result.add("F-PROJECTION", "exact projection declares a bound or residual", "B-PROJECTION", outcomes)
        return
    if mode == "BOUNDED" and residual != expected_residual:
        result.add("F-LOSS-OPEN", "bounded compression residual is not the exact typed discrepancy ledger", "B-PROJECTION", outcomes)
        return
    if projection_kind == "COMPRESSION" and len(set(projection_map.values())) >= len(states):
        result.add("F-PROJECTION", "compression does not strictly reduce the finite view cardinality", "B-PROJECTION", outcomes)
        return
    result.trace.append(f"projection:{projection_kind}:{mode}:{len(states)}-states")
    result.reverse = ["return-comparison", "reconstruction", "projection", "source-state"]
    result.value = {
        "type": "CompressionCertificate" if projection_kind == "COMPRESSION" else "ProjectionCertificate",
        "kind": projection_kind,
        "mode": mode,
        "states_checked": len(states),
        "bound": bound,
        "source_cardinality": len(states),
        "view_cardinality": len(set(projection_map.values())),
    }
    result.witness_bundle = {"projection_fingerprint": digest_object(projection_map, "PROJECTION"), "reverse": list(result.reverse)}


def evaluate_carrier(
    case: dict[str, Any], result: Evaluation, outcomes: dict[str, str], source: dict[str, Any], root: Path | None
) -> None:
    result.behaviors.update({"B-PUBLICATION", "B-OUTCOME"})
    try:
        report = validate_source(source)
        projection = readable_claims(source)
    except CRAError:
        report = None
        projection = []
    artifact_ok = False
    if root is not None:
        try:
            fixtures, vectors = load_vector_model(root / VECTORS_REL)
            artifact_ok = (
                bool(fixtures)
                and bool(vectors)
                and (root / SCRIPT_REL).is_file()
                and (root / SCRIPT_REL).stat().st_size > 0
                and (root / SKILL_REL).is_file()
                and (root / SKILL_REL).stat().st_size > 0
                and (root / LEXICON_REL).is_file()
                and validate_lexicon(read_json(root / LEXICON_REL))["entries"] > 0
            )
        except (CRAError, OSError):
            artifact_ok = False
    projected_ids = [row["source_id"] for section in projection for row in section["rows"]]
    ledger_ids = []
    for claim in source.get("claim_ledger", []):
        ledger_ids.extend([claim["source_id"]] if "source_id" in claim else claim.get("source_ids", []))
    if (
        set(case) - {"operation", "injected_drift"}
        or report is None
        or not artifact_ok
        or Counter(projected_ids) != Counter(ledger_ids)
        or case.get("injected_drift")
    ):
        result.add("F-CARRIER", "publication carrier trace or integrity is broken", "B-PUBLICATION", outcomes)
        return
    result.trace.append("carrier:source+lexicon->projection+runtime+vectors")
    result.offer_proof_artifact(
        "Carrier",
        {"claim_sources": len(projected_ids), "architecture_fingerprint": report["architecture_fingerprint"]},
        {"projection_fingerprint": readable_projection_fingerprint(source)},
    )
    result.reverse = ["vectors", "runtime", "readable-claim-ids", "structural-lexicon", "normative-source"]
    result.value = {"type": "CarrierCertificate", "claim_sources": len(projected_ids), "architecture_fingerprint": report["architecture_fingerprint"]}
    result.witness_bundle = {"projection_fingerprint": readable_projection_fingerprint(source), "reverse": list(result.reverse)}


def _evaluate_case_unsafe(case: dict[str, Any], source: dict[str, Any], root: Path | None = None) -> Evaluation:
    failure_outcomes = {row["id"]: row["outcome"] for row in source["failures"]}
    operation = case.get("operation")
    result = Evaluation(operation=str(operation or "unknown"))
    if operation == "rebind":
        evaluate_rebind(case, result, failure_outcomes)
    elif operation == "contextualize":
        evaluate_contextualize(case, result, failure_outcomes)
    elif operation == "judge":
        evaluate_judge(case, result, failure_outcomes)
    elif operation == "apply":
        evaluate_apply(case, result, failure_outcomes)
    elif operation == "admit":
        evaluate_admit(case, result, failure_outcomes)
    elif operation == "compose":
        evaluate_compose(case, result, failure_outcomes)
    elif operation == "reassess":
        evaluate_reassess(case, result, failure_outcomes)
    elif operation == "effect":
        evaluate_effect(case, result, failure_outcomes)
    elif operation == "projection":
        evaluate_projection(case, result, failure_outcomes)
    elif operation == "carrier":
        evaluate_carrier(case, result, failure_outcomes, source, root)
    else:
        result.add("F-INDEX", f"unknown operator {operation}", "B-INDEX", failure_outcomes)
    result.behaviors.add("B-OUTCOME")
    return result


def bounded_json_shape(value: Any, *, max_depth: int = 128, max_nodes: int = 100_000) -> bool:
    stack: list[tuple[Any, int]] = [(value, 0)]
    nodes = 0
    while stack:
        current, depth = stack.pop()
        nodes += 1
        if depth > max_depth or nodes > max_nodes:
            return False
        if isinstance(current, dict):
            stack.extend((item, depth + 1) for item in current.values())
        elif isinstance(current, list):
            stack.extend((item, depth + 1) for item in current)
    return True


def evaluate_case(case: Any, source: dict[str, Any], root: Path | None = None) -> Evaluation:
    failure_outcomes = {row["id"]: row["outcome"] for row in source["failures"]}
    if not isinstance(case, dict):
        result = Evaluation()
        result.add("F-INTEGRITY", "input case is not a typed object", "B-OUTCOME", failure_outcomes)
        return result
    if not bounded_json_shape(case):
        result = Evaluation()
        result.add("F-INTEGRITY", "input exceeds the finite profile's structural depth or size bound", "B-OUTCOME", failure_outcomes)
        return result
    try:
        canonical_case = normalize(case)
        return finalize_evaluation(canonical_case, _evaluate_case_unsafe(canonical_case, source, root))
    except (AttributeError, IndexError, KeyError, TypeError, ValueError, RecursionError, CRAError) as exc:
        result = Evaluation()
        result.add(
            "F-INTEGRITY",
            f"malformed case was contained as a structured refusal: {type(exc).__name__}",
            "B-OUTCOME",
            failure_outcomes,
        )
        return result


def resolve_vector(vector: dict[str, Any], fixtures: dict[str, dict[str, Any]]) -> dict[str, Any]:
    return apply_mutations(fixtures[vector["base"]], vector.get("mutations", []))


def qualify(root: Path, *, include_results: bool = False) -> dict[str, Any]:
    source = read_json(root / SOURCE_REL)
    source_report = validate_source(source)
    lexicon_report = validate_lexicon(read_json(root / LEXICON_REL))
    fixtures, vectors = load_vector_model(root / VECTORS_REL)
    results: list[dict[str, Any]] = []
    failures: list[str] = []
    expected_failure_reach: set[str] = set()
    positive_behavior: set[str] = set()
    refusing_behavior: set[str] = set()
    kind_counts: Counter[str] = Counter()
    law_countermodels: set[str] = set()
    root_ablations: set[str] = set()
    earned_operators: set[str] = set()
    open_operators: set[str] = set()
    mutation_contract = {row["id"]: row for row in source["mutation_contract"]}
    killed_mutations: set[str] = set()
    entry_probes = (
        '{"x":0,"x":1}',
        '{"é":0,"é":1}',
        '{"x":NaN}',
        '{"x":Infinity}',
        '{"x":1.5}',
    )
    entry_contracts_passed = 0
    for probe in entry_probes:
        try:
            strict_json_loads(probe)
        except CRAError:
            entry_contracts_passed += 1
    deep_probe: Any = "leaf"
    for _ in range(130):
        deep_probe = {"x": deep_probe}
    if not bounded_json_shape(deep_probe):
        entry_contracts_passed += 1
    entry_contracts_total = len(entry_probes) + 1
    if entry_contracts_passed != entry_contracts_total:
        failures.append(
            f"entry canonicality/structural contracts: {entry_contracts_passed}/{entry_contracts_total}"
        )

    for vector in vectors:
        case = resolve_vector(vector, fixtures)
        evaluation = evaluate_case(case, source, root)
        expected = vector["expect"]
        expected_codes = set(expected.get("failures", []))
        actual_codes = set(evaluation.failure_codes)
        finding_pairs = {(finding.code, finding.behavior) for finding in evaluation.findings}
        passed = evaluation.outcome == expected["outcome"] and expected_codes == actual_codes
        kind_counts[vector["kind"]] += 1
        covers = set(vector.get("covers", []))
        behavior_covers = {item for item in covers if item.startswith("B-")}
        target_ids = set(vector.get("targets", []))
        undeclared_execution = behavior_covers - evaluation.behaviors
        if undeclared_execution:
            passed = False
            failures.append(f"{vector['id']}: claims unexecuted behavior coverage {sorted(undeclared_execution)}")
        assertions = vector.get("assert", {})
        if expected["outcome"] == "EARNED":
            if not assertions:
                passed = False
                failures.append(f"{vector['id']}: EARNED vector has no value/trace assertions")
            value = evaluation.value or {}
            if not assertions.get("value_type") or value.get("type") != assertions["value_type"]:
                passed = False
                failures.append(f"{vector['id']}: value type assertion failed")
            assertion_missing = object()
            for pointer, expected_value in assertions.get("value_equals", {}).items():
                if pointer_get(value, pointer, assertion_missing) != expected_value:
                    passed = False
                    failures.append(f"{vector['id']}: value assertion failed at {pointer}")
            if not assertions.get("forward_contains") or not evaluation.trace or not set(assertions.get("forward_contains", [])) <= set(evaluation.trace):
                passed = False
                failures.append(f"{vector['id']}: forward-trace assertion failed")
            if not assertions.get("reverse_contains") or not evaluation.reverse or not set(assertions.get("reverse_contains", [])) <= set(evaluation.reverse):
                passed = False
                failures.append(f"{vector['id']}: reverse-trace assertion failed")
            if assertions.get("witness_required") and not evaluation.witness_bundle:
                passed = False
                failures.append(f"{vector['id']}: witness bundle assertion failed")
            expected_result_fingerprint = assertions.get("result_fingerprint")
            actual_result_fingerprint = digest_object(evaluation.as_dict(), "EVALUATION")
            if not isinstance(expected_result_fingerprint, str) or expected_result_fingerprint != actual_result_fingerprint:
                passed = False
                failures.append(f"{vector['id']}: exact result fingerprint assertion failed")
        elif expected["outcome"] == "OPEN":
            certificate_issues = validate_open_certificate(evaluation.open_certificate)
            if not evaluation.findings or not evaluation.affected_returns or not evaluation.recovery_ports or certificate_issues:
                passed = False
                failures.append(
                    f"{vector['id']}: OPEN result lacks an exact noncompletion certificate: {certificate_issues}"
                )
            expected_open_fingerprint = assertions.get("open_certificate_fingerprint")
            actual_open_fingerprint = (evaluation.open_certificate or {}).get("certificate_fingerprint")
            if not isinstance(expected_open_fingerprint, str) or expected_open_fingerprint != actual_open_fingerprint:
                passed = False
                failures.append(f"{vector['id']}: exact OpenCertificate fingerprint assertion failed")
        elif evaluation.open_certificate is not None:
            passed = False
            failures.append(f"{vector['id']}: non-OPEN result carries an OpenCertificate")
        if target_ids:
            if expected["outcome"] == "EARNED":
                passed = False
                failures.append(f"{vector['id']}: mutation targets require a refusing vector")
            mutation_paths = {mutation.get("path") for mutation in vector.get("mutations", [])}
            for target_id in sorted(target_ids):
                target = mutation_contract.get(target_id)
                if target is None:
                    passed = False
                    failures.append(f"{vector['id']}: unknown mutation target {target_id}")
                    continue
                if target["path"] not in mutation_paths:
                    passed = False
                    failures.append(
                        f"{vector['id']}: target {target_id} does not mutate its declared path {target['path']}"
                    )
                if target["behavior"] not in behavior_covers or target["behavior"] not in evaluation.behaviors:
                    passed = False
                    failures.append(
                        f"{vector['id']}: target {target_id} did not execute and cover {target['behavior']}"
                    )
                if target["failure"] not in expected_codes or target["failure"] not in actual_codes:
                    passed = False
                    failures.append(
                        f"{vector['id']}: target {target_id} did not produce {target['failure']}"
                    )
                if (target["failure"], target["behavior"]) not in finding_pairs:
                    passed = False
                    failures.append(
                        f"{vector['id']}: target {target_id} was not attributed to "
                        f"{target['behavior']}/{target['failure']}"
                    )
        if not passed and not any(message.startswith(f"{vector['id']}:") for message in failures):
            failures.append(
                f"{vector['id']}: expected {expected['outcome']}/{sorted(expected_codes)}, got {evaluation.outcome}/{sorted(actual_codes)}"
            )
        if passed:
            if expected["outcome"] == "EARNED":
                positive_behavior |= behavior_covers & evaluation.behaviors
                earned_operators.add(case.get("operation", ""))
            else:
                refusing_behavior |= behavior_covers & evaluation.behaviors
                expected_failure_reach |= expected_codes
                killed_mutations |= target_ids
                if expected["outcome"] == "OPEN":
                    open_operators.add(case.get("operation", ""))
            if vector["kind"] == "countermodel":
                targeted_laws = {item for item in covers if item.startswith("L-")}
                for law_id in targeted_laws:
                    law = next(row for row in source["laws"] if row["id"] == law_id)
                    target_behaviors = {
                        mutation_contract[target_id]["behavior"]
                        for target_id in target_ids
                        if target_id in mutation_contract
                    }
                    if set(law.get("behavior_refs", [])) & target_behaviors & behavior_covers:
                        law_countermodels.add(law_id)
            if vector["kind"] == "ablation":
                root_ablations |= {item for item in covers if item.startswith("R-")}
        results.append(
            {
                "id": vector["id"],
                "kind": vector["kind"],
                "passed": passed,
                "expected": expected,
                "actual": evaluation.as_dict(),
                "covers": vector.get("covers", []),
                "targets": vector.get("targets", []),
            }
        )

    passed_vector_ids = {row["id"] for row in results if row["passed"]}
    profile_cells_without_evidence = sorted(
        row["id"]
        for row in source["profile_qualification"]["cells"]
        if row["status"] == "E1_EXECUTED_FINITE"
        and not set(row["evidence_vectors"]) <= passed_vector_ids
    )
    succession_probes: list[tuple[str, Any]] = [
        ("root omission", lambda material: material["lineage"]["succession_account"]["root_dispositions"].pop()),
        ("law duplication", lambda material: material["lineage"]["succession_account"]["law_dispositions"].append(copy.deepcopy(material["lineage"]["succession_account"]["law_dispositions"][0]))),
        ("frontier omission", lambda material: material["lineage"]["succession_account"]["frontier_dispositions"].pop()),
        ("unsupported frontier closure", lambda material: material["lineage"]["succession_account"]["frontier_dispositions"][0].update({"status": "CLOSED", "closure_claimed": True})),
        ("status inheritance", lambda material: material["lineage"]["succession_account"]["destination"].update({"status_inherited": True})),
    ]
    succession_probes_passed = 0
    for name, mutate in succession_probes:
        probe_source = copy.deepcopy(source)
        mutate(probe_source)
        try:
            validate_source(probe_source)
        except CRAError:
            succession_probes_passed += 1
        else:
            failures.append(f"succession mutation survived: {name}")
    open_certificate_mutations_passed = 0
    open_certificate_mutations_total = 4
    sample_certificate = next(
        (row["actual"].get("open_certificate") for row in results if row["passed"] and row["expected"]["outcome"] == "OPEN"),
        None,
    )
    if isinstance(sample_certificate, dict):
        missing_break = copy.deepcopy(sample_certificate)
        missing_break.pop("first_break", None)
        false_reentry = copy.deepcopy(sample_certificate)
        false_reentry["smallest_reentry"]["dependency_ref"] = "/unrelated"
        unrelated_scope = copy.deepcopy(sample_certificate)
        unrelated_scope["affected_return_components"].append(
            {"demand_ref": "UNRELATED", "component": "return", "path": "/x", "return": "x"}
        )
        false_fingerprint = copy.deepcopy(sample_certificate)
        false_fingerprint["certificate_fingerprint"] = "0" * 64
        open_certificate_mutations_passed = sum(
            bool(validate_open_certificate(probe))
            for probe in (missing_break, false_reentry, unrelated_scope, false_fingerprint)
        )
    if open_certificate_mutations_passed != open_certificate_mutations_total:
        failures.append(
            f"OpenCertificate mutation probes: {open_certificate_mutations_passed}/{open_certificate_mutations_total}"
        )

    behavior_ids = {row["id"] for row in source["behaviors"]}
    failure_ids = {row["id"] for row in source["failures"]}
    law_ids = {row["id"] for row in source["laws"]}
    root_ids = {row["id"] for row in source["roots"]}
    required_kinds = set(source["coverage_contract"]["required_vector_kinds"])
    required_operators = {row["name"].lower() for row in source["operators"]}
    coverage_gaps = {
        "behaviors_without_positive": sorted(behavior_ids - positive_behavior),
        "behaviors_without_refusal": sorted(behavior_ids - refusing_behavior),
        "unreached_failures": sorted(failure_ids - expected_failure_reach),
        "laws_without_countermodel": sorted(law_ids - law_countermodels),
        "roots_without_ablation": sorted(root_ids - root_ablations),
        "missing_vector_kinds": sorted(required_kinds - set(kind_counts)),
        "operators_without_earned_value": sorted(required_operators - earned_operators),
        "operators_without_open_certificate": sorted(required_operators - open_operators),
        "unkilled_mutation_targets": sorted(set(mutation_contract) - killed_mutations),
        "profile_cells_without_evidence": profile_cells_without_evidence,
    }
    if any(coverage_gaps.values()):
        failures.append(f"coverage gaps: {coverage_gaps}")
    if failures:
        status = "FAIL"
    else:
        status = "PASS"
    qualification_core = {
        "instrument": "CRA v1.1 finite reference qualification",
        "status": status,
        "version": VERSION,
        "source": source_report,
        "lexicon": lexicon_report,
        "vectors": {"total": len(vectors), "passed": sum(row["passed"] for row in results), "failed": sum(not row["passed"] for row in results)},
        "vector_kinds": dict(sorted(kind_counts.items())),
        "coverage": {
            "behaviors_positive": f"{len(positive_behavior)}/{len(behavior_ids)}",
            "behaviors_refusal": f"{len(refusing_behavior)}/{len(behavior_ids)}",
            "failure_codes_reached": f"{len(expected_failure_reach)}/{len(failure_ids)}",
            "law_countermodels": f"{len(law_countermodels)}/{len(law_ids)}",
            "root_ablations": f"{len(root_ablations)}/{len(root_ids)}",
            "claim_projection": f"{source_report['claims']}/{source_report['claims']}",
            "operator_values": f"{len(required_operators & earned_operators)}/{len(required_operators)}",
            "operator_open_certificates": f"{len(required_operators & open_operators)}/{len(required_operators)}",
            "mutation_targets": f"{len(killed_mutations)}/{len(mutation_contract)}",
            "entry_contracts": f"{entry_contracts_passed}/{entry_contracts_total}",
            "succession_mutations": f"{succession_probes_passed}/{len(succession_probes)}",
            "open_certificate_mutations": f"{open_certificate_mutations_passed}/{open_certificate_mutations_total}",
            "gaps": coverage_gaps,
        },
        "failures": failures,
        "boundary": source["coverage_contract"]["meaning_of_100_percent"],
    }
    qualification_core["qualification_fingerprint"] = digest_object(
        {"vectors": results, "coverage": qualification_core["coverage"]}, "QUALIFICATION"
    )
    if include_results:
        qualification_core["results"] = results
    return qualification_core


def readable_claims(source: dict[str, Any]) -> list[dict[str, Any]]:
    index = source_index(source)
    claims = {row["id"]: row for row in source["claim_ledger"]}
    resolved: list[dict[str, Any]] = []
    for section in source["readable_projection"]:
        rows: list[dict[str, str]] = []
        for claim_ref in section["claim_refs"]:
            claim = claims[claim_ref]
            refs = [claim["source_id"]] if "source_id" in claim else claim["source_ids"]
            for ref in refs:
                rows.append({"claim_id": claim_ref, "source_id": ref, "text": index[ref]["public"]})
        resolved.append({"id": section["id"], "heading": section["heading"], "rows": rows})
    return resolved


def readable_projection_fingerprint(source: dict[str, Any]) -> str:
    return digest_object(readable_claims(source), "READABLE-PROJECTION")


def render_docx(root: Path, output: Path, qualification: dict[str, Any]) -> None:
    try:
        from docx import Document
        from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.oxml import OxmlElement
        from docx.oxml.ns import qn
        from docx.opc.constants import RELATIONSHIP_TYPE as RT
        from docx.shared import Inches, Pt, RGBColor
    except ImportError as exc:
        raise CRAError("DOCX rendering requires python-docx; verification does not") from exc

    source = read_json(root / SOURCE_REL)
    validate_source(source)
    projection = readable_claims(source)
    index = source_index(source)
    doc = Document()
    section = doc.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(1.0)
    section.bottom_margin = Inches(1.0)
    section.left_margin = Inches(1.0)
    section.right_margin = Inches(1.0)
    section.header_distance = Inches(0.492)
    section.footer_distance = Inches(0.492)

    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = "Calibri"
    normal.font.size = Pt(11)
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.25
    for name, size, color, before, after in (
        ("Title", 26, "17324D", 0, 8),
        ("Subtitle", 11, "526B7A", 0, 12),
        ("Heading 1", 16, "2E74B5", 18, 10),
        ("Heading 2", 13, "1F4D78", 14, 7),
        ("Heading 3", 12, "1F4D78", 10, 5),
    ):
        style = styles[name]
        style.font.name = "Calibri"
        style.font.size = Pt(size)
        style.font.color.rgb = RGBColor.from_string(color)
        style.font.bold = name != "Subtitle"
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        style.paragraph_format.keep_with_next = True

    def shade(cell: Any, color: str) -> None:
        tc_pr = cell._tc.get_or_add_tcPr()
        shd = tc_pr.find(qn("w:shd"))
        if shd is None:
            shd = OxmlElement("w:shd")
            tc_pr.append(shd)
        shd.set(qn("w:fill"), color)

    def set_cell_margins(cell: Any, top: int = 80, start: int = 120, bottom: int = 80, end: int = 120) -> None:
        tc = cell._tc
        tc_pr = tc.get_or_add_tcPr()
        tc_mar = tc_pr.first_child_found_in("w:tcMar")
        if tc_mar is None:
            tc_mar = OxmlElement("w:tcMar")
            tc_pr.append(tc_mar)
        for margin, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
            node = tc_mar.find(qn(f"w:{margin}"))
            if node is None:
                node = OxmlElement(f"w:{margin}")
                tc_mar.append(node)
            node.set(qn("w:w"), str(value))
            node.set(qn("w:type"), "dxa")

    header = section.header
    header_table = header.add_table(rows=1, cols=2, width=Inches(6.5))
    header_table.autofit = False
    header_table.columns[0].width = Inches(4.65)
    header_table.columns[1].width = Inches(1.85)
    left_header = header_table.cell(0, 0).paragraphs[0]
    left_header.paragraph_format.space_after = Pt(0)
    left_run = left_header.add_run("CRA · CONTEXTUAL REBINDING ARCHITECTURE")
    left_run.bold = True
    left_run.font.size = Pt(8.5)
    left_run.font.color.rgb = RGBColor.from_string("526B7A")
    right_header = header_table.cell(0, 1).paragraphs[0]
    right_header.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    right_header.paragraph_format.space_after = Pt(0)
    right_run = right_header.add_run("v1.1 · 08 AUG 2026")
    right_run.font.size = Pt(8.5)
    right_run.font.color.rgb = RGBColor.from_string("526B7A")
    for header_cell in header_table.rows[0].cells:
        tc_pr = header_cell._tc.get_or_add_tcPr()
        borders = OxmlElement("w:tcBorders")
        for edge_name in ("top", "left", "bottom", "right", "insideH", "insideV"):
            edge = OxmlElement(f"w:{edge_name}")
            edge.set(qn("w:val"), "nil")
            borders.append(edge)
        tc_pr.append(borders)

    footer = section.footer
    footer_p = footer.paragraphs[0]
    footer_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    footer_p.paragraph_format.space_after = Pt(0)
    footer_run = footer_p.add_run("CURRENT RESEARCH BASELINE   ·   ")
    footer_run.font.size = Pt(8.5)
    footer_run.font.color.rgb = RGBColor.from_string("6B7D8A")
    page_field = OxmlElement("w:fldSimple")
    page_field.set(qn("w:instr"), "PAGE")
    footer_p._p.append(page_field)

    title = doc.add_paragraph(style="Title")
    title.add_run("Contextual Rebinding\nArchitecture v1.1")
    subtitle = doc.add_paragraph(style="Subtitle")
    subtitle.add_run(source["core"]["short_line"])

    box = doc.add_table(rows=1, cols=1)
    box.alignment = WD_TABLE_ALIGNMENT.CENTER
    box.autofit = False
    box.columns[0].width = Inches(6.5)
    cell = box.cell(0, 0)
    shade(cell, "E8F1F8")
    set_cell_margins(cell, 150, 120, 150, 120)
    paragraph = cell.paragraphs[0]
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    core_run = paragraph.add_run(source["core"]["public"])
    core_run.bold = True
    core_run.font.size = Pt(12)
    core_run.font.color.rgb = RGBColor.from_string("17324D")
    baseline = doc.add_paragraph(source["release"]["public"])
    baseline.runs[0].bold = True
    baseline.runs[0].font.color.rgb = RGBColor.from_string("1F4D78")
    doc.add_paragraph(source["purpose"]["public"])
    doc.add_paragraph(source["scope"]["public"])
    doc.add_paragraph(source["index"]["public"])

    def set_table_geometry(table: Any, widths: list[float]) -> None:
        width_dxa = 9360
        grid_widths = [round(width * 1440) for width in widths]
        if sum(grid_widths) != width_dxa:
            grid_widths[-1] += width_dxa - sum(grid_widths)
        table.autofit = False
        table.alignment = WD_TABLE_ALIGNMENT.CENTER
        tbl_pr = table._tbl.tblPr
        tbl_w = tbl_pr.find(qn("w:tblW"))
        if tbl_w is None:
            tbl_w = OxmlElement("w:tblW")
            tbl_pr.append(tbl_w)
        tbl_w.set(qn("w:w"), str(width_dxa))
        tbl_w.set(qn("w:type"), "dxa")
        tbl_ind = tbl_pr.find(qn("w:tblInd"))
        if tbl_ind is None:
            tbl_ind = OxmlElement("w:tblInd")
            tbl_pr.append(tbl_ind)
        tbl_ind.set(qn("w:w"), "120")
        tbl_ind.set(qn("w:type"), "dxa")
        layout = tbl_pr.find(qn("w:tblLayout"))
        if layout is None:
            layout = OxmlElement("w:tblLayout")
            tbl_pr.append(layout)
        layout.set(qn("w:type"), "fixed")
        grid = table._tbl.tblGrid
        for child in list(grid):
            grid.remove(child)
        for width in grid_widths:
            column = OxmlElement("w:gridCol")
            column.set(qn("w:w"), str(width))
            grid.append(column)
        for row in table.rows:
            for index, cell in enumerate(row.cells):
                tc_pr = cell._tc.get_or_add_tcPr()
                tc_w = tc_pr.find(qn("w:tcW"))
                if tc_w is None:
                    tc_w = OxmlElement("w:tcW")
                    tc_pr.append(tc_w)
                tc_w.set(qn("w:w"), str(grid_widths[index]))
                tc_w.set(qn("w:type"), "dxa")

    def add_compact_table(headers: list[str], rows: list[list[str]], widths: list[float]) -> None:
        table = doc.add_table(rows=1, cols=len(headers))
        table.style = "Table Grid"
        set_table_geometry(table, widths)
        for idx, (header_text, width) in enumerate(zip(headers, widths)):
            table.columns[idx].width = Inches(width)
            cell = table.rows[0].cells[idx]
            cell.width = Inches(width)
            shade(cell, "DCE9F3")
            set_cell_margins(cell)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            p = cell.paragraphs[0]
            p.paragraph_format.space_after = Pt(0)
            r = p.add_run(header_text)
            r.bold = True
            r.font.size = Pt(9.4)
            r.font.color.rgb = RGBColor.from_string("17324D")
        header_properties = table.rows[0]._tr.get_or_add_trPr()
        header_properties.append(OxmlElement("w:tblHeader"))
        header_properties.append(OxmlElement("w:cantSplit"))
        for row_values in rows:
            cells = table.add_row().cells
            set_table_geometry(table, widths)
            table.rows[-1]._tr.get_or_add_trPr().append(OxmlElement("w:cantSplit"))
            for idx, (text, width) in enumerate(zip(row_values, widths)):
                cells[idx].width = Inches(width)
                set_cell_margins(cells[idx])
                cells[idx].vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.TOP
                p = cells[idx].paragraphs[0]
                p.paragraph_format.space_after = Pt(0)
                p.paragraph_format.line_spacing = 1.15
                r = p.add_run(text)
                r.font.size = Pt(9.3)
        spacer = doc.add_paragraph()
        spacer.paragraph_format.space_after = Pt(0)
        spacer.paragraph_format.line_spacing = 0.7

    set_table_geometry(box, [6.5])
    set_table_geometry(header_table, [4.65, 1.85])

    doc.add_heading("Seven roots", level=1)
    root_rows = [[row["name"] + " —", row["public"].split(" — ", 1)[1]] for row in source["roots"]]
    add_compact_table(["Root", "Irreducible job"], root_rows, [1.35, 5.15])

    doc.add_heading("Six laws", level=1)
    for law in source["laws"]:
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.08)
        p.paragraph_format.first_line_indent = Inches(-0.08)
        p.paragraph_format.keep_together = True
        prefix, rest = law["public"].split(" — ", 1)
        run = p.add_run(prefix + " — ")
        run.bold = True
        run.font.color.rgb = RGBColor.from_string("1F4D78")
        p.add_run(rest)

    doc.add_heading("Outcomes and operation", level=1)
    outcome_rows = [[row["name"] + " —", row["public"].split(" — ", 1)[1]] for row in source["outcomes"]]
    add_compact_table(["Outcome", "Meaning"], outcome_rows, [1.25, 5.25])
    operator_rows = [[row["name"], row["public"]] for row in source["operators"]]
    add_compact_table(["Operator", "Job"], operator_rows, [1.35, 5.15])
    for item_id in ("D-CONTEXT", "D-CLAIM", "D-REBINDING", "D-CHANGE"):
        doc.add_paragraph(index[item_id]["public"], style="Normal")

    doc.add_heading("OPEN is an exact return", level=1)
    doc.add_paragraph(source["open_certificate_contract"]["public"])
    open_rows = [
        ["First break", "The first unavailable prerequisite in the fail-fast operator order, with exact failure code and dependency reference."],
        ["Weaker result", "The deepest independently verified proof artifact, or the explicit value NONE_EARNED."],
        ["Obligations", "The detected proof obligation plus live resource obligations disclosed by validated Basis closures."],
        ["Return scope", "Only the destination Demand component or typed operator Return reached by the break."],
        ["Reverse evidence", "Content-bound reconstruction of the verified prefix, break, and dependency reference."],
        ["Reentry", "The earliest invalidated dependency and its lawful recovery action—not a claim of globally minimum edit distance."],
    ]
    add_compact_table(["Certificate field", "Finite v1.1 meaning"], open_rows, [1.45, 5.05])
    boundary_note = doc.add_paragraph(source["open_certificate_contract"]["detection_boundary"])
    boundary_note.runs[0].italic = True

    doc.add_heading("Correspondence and accounting", level=1)
    doc.add_paragraph(index["C-CORR-SEM"]["public"])
    doc.add_paragraph(index["C-ACCOUNT-SEM"]["public"])

    doc.add_heading("Profiles, not kinds", level=1)
    doc.add_paragraph(index["C-DIMENSIONS"]["public"])
    profile_rows = [[row["name"] + " —", row["public"].split(" — ", 1)[1]] for row in source["profiles"]]
    add_compact_table(["Profile", "Additional proof duties"], profile_rows, [1.35, 5.15])

    doc.add_heading("Exact profile evidence", level=2)
    doc.add_paragraph(source["profile_qualification"]["public"])
    cell_rows: list[list[str]] = []
    for cell_row in source["profile_qualification"]["cells"]:
        dimensions = "; ".join(f"{key}={value}" for key, value in cell_row["dimensions"].items())
        evidence = ", ".join(cell_row["evidence_vectors"]) or "none"
        cell_rows.append([
            cell_row["id"].removeprefix("Q-"),
            cell_row["profile_ref"],
            cell_row["status"].replace("_", " "),
            f"{dimensions}. Evidence: {evidence}.",
        ])
    add_compact_table(["Cell", "Profile", "Status", "Exact dimensions and evidence"], cell_rows, [1.2, 0.9, 1.35, 3.05])

    doc.add_heading("Qualification", level=1)
    coverage = qualification["coverage"]
    readable_statement_count = sum(len(section["rows"]) for section in projection)
    summary = (
        f"{qualification['vectors']['passed']}/{qualification['vectors']['total']} shipped vectors passed. "
        f"Positive/refusal behavior coverage: {coverage['behaviors_positive']} / {coverage['behaviors_refusal']}. "
        f"Failure reach: {coverage['failure_codes_reached']}; law countermodels: {coverage['law_countermodels']}; "
        f"root ablations: {coverage['root_ablations']}; clause mutations: {coverage['mutation_targets']}; "
        f"entry contracts: {coverage['entry_contracts']}; operator values: {coverage['operator_values']}; "
        f"operator OPEN certificates: {coverage['operator_open_certificates']}; "
        f"succession mutations: {coverage['succession_mutations']}; OPEN mutations: {coverage['open_certificate_mutations']}; "
        f"readable ledger: {coverage['claim_projection']} "
        f"({readable_statement_count}/{readable_statement_count} source statements). "
        f"The optional Structural Lexicon binds {qualification['lexicon']['entries']} terms across "
        f"{qualification['lexicon']['categories']} categories without normative authority."
    )
    qualification_summary = doc.add_paragraph(summary)
    qualification_summary.paragraph_format.keep_with_next = True
    doc.add_paragraph(source["coverage_contract"]["meaning_of_100_percent"])

    doc.add_heading("Hard boundary", level=1)
    boundary_rows = [[row["id"].removeprefix("N-").title(), row["public"]] for row in source["boundaries"]]
    add_compact_table(["Not internally earned", "Boundary"], boundary_rows, [1.45, 5.05])

    doc.add_heading("Succession and open frontiers", level=1)
    succession = source["lineage"]["succession_account"]
    doc.add_paragraph(succession["public"])
    frontier_rows = [
        [row["id"], row["name"], row["status"], row["closure_predicate"], row["reentry"]]
        for row in succession["frontier_dispositions"]
    ]
    add_compact_table(
        ["ID", "Frontier", "Status", "Closure predicate", "Reentry"],
        frontier_rows,
        [0.62, 1.12, 0.65, 2.55, 1.56],
    )
    succession_counts = qualification["source"]["succession"]
    doc.add_paragraph(
        f"Executed disposition universe: {succession_counts['roots']} predecessor roots; "
        f"{succession_counts['laws']} laws; {succession_counts['profiles']} profiles; "
        f"{succession_counts['frontiers']} carried OPEN frontiers. Status inheritance: forbidden."
    )

    doc.add_heading("Structural Lexicon", level=1)
    lexicon = read_json(root / LEXICON_REL)
    doc.add_paragraph(
        f"The optional Structural Lexicon is a lookup-only sidecar containing {len(lexicon['entries'])} structural terms in "
        f"{len(lexicon['categories'])} categories. It preserves vocabulary from CRA, TSP, Coherence Machine, Leverage Machine, "
        "Architecture+, DSA, and DST while keeping historical and domain terms out of the seven-root kernel."
    )
    lexicon_rule = doc.add_paragraph(lexicon["nonimplication"])
    lexicon_rule.runs[0].bold = True
    category_rows = [[row["id"], str(row["entry_count"])] for row in lexicon["categories"]]
    midpoint = (len(category_rows) + 1) // 2
    left_categories = category_rows[:midpoint]
    right_categories = category_rows[midpoint:]
    lexicon_rows = [
        left_categories[index] + (right_categories[index] if index < len(right_categories) else ["", ""])
        for index in range(len(left_categories))
    ]
    add_compact_table(["Category", "Terms", "Category", "Terms"], lexicon_rows, [2.65, 0.6, 2.65, 0.6])

    doc.add_heading("What changed", level=1)
    lineage_paragraph = doc.add_paragraph(source["lineage"]["public"])
    lineage_paragraph.paragraph_format.keep_with_next = True
    delta_rows = [
        ["Preserved", "; ".join(source["lineage"]["preserved"])],
        ["Removed", "; ".join(source["lineage"]["removed"])],
    ]
    add_compact_table(["v1.1", "Conserved and removed across the research line"], delta_rows, [1.25, 5.25])

    foundation_heading = doc.add_heading("Established foundations", level=1)
    foundation_heading.paragraph_format.space_before = Pt(10)
    foundation_heading.paragraph_format.space_after = Pt(6)
    def add_hyperlink(paragraph: Any, text: str, url: str) -> None:
        relationship_id = paragraph.part.relate_to(url, RT.HYPERLINK, is_external=True)
        hyperlink = OxmlElement("w:hyperlink")
        hyperlink.set(qn("r:id"), relationship_id)
        hyperlink.set(qn("w:history"), "1")
        run = OxmlElement("w:r")
        properties = OxmlElement("w:rPr")
        color = OxmlElement("w:color")
        color.set(qn("w:val"), "2E74B5")
        underline = OxmlElement("w:u")
        underline.set(qn("w:val"), "single")
        size = OxmlElement("w:sz")
        size.set(qn("w:val"), "18")
        properties.extend((color, underline, size))
        run.append(properties)
        text_node = OxmlElement("w:t")
        text_node.text = text
        run.append(text_node)
        hyperlink.append(run)
        paragraph._p.append(hyperlink)

    foundation_table = doc.add_table(rows=3, cols=2)
    set_table_geometry(foundation_table, [3.25, 3.25])
    foundation_table.autofit = False
    for index, ref in enumerate(source["research_basis"]):
        cell = foundation_table.cell(index % 3, index // 3)
        set_cell_margins(cell, 45, 120, 45, 120)
        tc_pr = cell._tc.get_or_add_tcPr()
        borders = OxmlElement("w:tcBorders")
        for edge_name in ("top", "left", "bottom", "right"):
            edge = OxmlElement(f"w:{edge_name}")
            edge.set(qn("w:val"), "nil")
            borders.append(edge)
        tc_pr.append(borders)
        p = cell.paragraphs[0]
        p.paragraph_format.space_after = Pt(0)
        p.paragraph_format.line_spacing = 1.08
        r = p.add_run(ref["name"] + ". ")
        r.bold = True
        r.font.size = Pt(9.2)
        r.font.size = Pt(8.9)
        add_hyperlink(p, "Source", ref["url"])

    output.parent.mkdir(parents=True, exist_ok=True)
    doc.save(output)
    canonicalize_office_archive(output)


def canonicalize_office_archive(path: Path) -> None:
    """Remove container-clock drift while preserving member bytes and order."""
    descriptor, temporary_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".canonical", dir=path.parent)
    os.close(descriptor)
    temporary = Path(temporary_name)
    try:
        with zipfile.ZipFile(path, "r") as source_archive, zipfile.ZipFile(
            temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9
        ) as target_archive:
            for member in source_archive.infolist():
                canonical = zipfile.ZipInfo(member.filename, date_time=(1980, 1, 1, 0, 0, 0))
                canonical.create_system = 3
                canonical.external_attr = member.external_attr
                canonical.compress_type = member.compress_type
                canonical.flag_bits = member.flag_bits
                target_archive.writestr(canonical, source_archive.read(member.filename))
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def extract_docx_text(path: Path) -> str:
    import xml.etree.ElementTree as ET

    with zipfile.ZipFile(path) as archive:
        xml = archive.read("word/document.xml")
    root = ET.fromstring(xml)
    namespace = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    raw = " ".join(node.text or "" for node in root.iter(namespace + "t"))
    return re.sub(r"\s+", " ", unicodedata.normalize("NFC", raw)).strip()


def verify_docx_projection(source: dict[str, Any], docx: Path, canonical_text: str | None = None) -> list[str]:
    text = extract_docx_text(docx)
    issues: list[str] = []
    positions: list[int] = []
    for section in readable_claims(source):
        for row in section["rows"]:
            expected = re.sub(r"\s+", " ", unicodedata.normalize("NFC", row["text"])).strip()
            count = text.count(expected)
            if count != 1:
                issues.append(f"{row['source_id']}:{'missing' if count == 0 else 'duplicate'}")
            else:
                positions.append(text.find(expected))
    if positions != sorted(positions):
        issues.append("projection:misordered")
    if canonical_text is not None and text != canonical_text:
        issues.append("projection:noncanonical-visible-text")
    return issues


def build_manifest(root: Path, docx: Path, qualification: dict[str, Any]) -> dict[str, Any]:
    source = read_json(root / SOURCE_REL)
    source_report = validate_source(source)
    lexicon_report = validate_lexicon(read_json(root / LEXICON_REL))
    files = {}
    for rel in (SKILL_REL, SOURCE_REL, LEXICON_REL, SCRIPT_REL, VECTORS_REL):
        files[str(rel)] = {"sha256": raw_sha256(root / rel), "bytes": (root / rel).stat().st_size}
    body: dict[str, Any] = {
        "release": "CRA v1.1",
        "packet_members": [str(path) for path in PACKET_ALLOWLIST],
        "architecture_fingerprint": source_report["architecture_fingerprint"],
        "succession_fingerprint": source_report["succession"]["fingerprint"],
        "structural_lexicon": lexicon_report,
        "qualification_fingerprint": qualification["qualification_fingerprint"],
        "readable_projection_fingerprint": readable_projection_fingerprint(source),
        "coverage": qualification["coverage"],
        "files": files,
        "external_readable": {"name": docx.name, "sha256": raw_sha256(docx), "bytes": docx.stat().st_size},
        "integrity_boundary": "SHA-256 detects byte drift; it does not prove authorship, trusted time, authenticity, safety, or semantic truth.",
    }
    body["release_fingerprint"] = digest_object(body, "RELEASE")
    body["manifest_content_fingerprint"] = digest_object(body, "MANIFEST")
    return body


def canonical_zip(root: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for rel in PACKET_ALLOWLIST:
            path = root / rel
            if not path.is_file():
                raise CRAError(f"packet allowlist member missing: {rel}")
            info = zipfile.ZipInfo(f"CRA-v1.1/{rel.as_posix()}", date_time=(1980, 1, 1, 0, 0, 0))
            info.create_system = 3
            info.external_attr = 0o644 << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, path.read_bytes())


def verify_manifest(root: Path, docx: Path | None = None, *, strict_docx_bytes: bool = True) -> dict[str, Any]:
    manifest_path = root / MANIFEST_REL
    if not manifest_path.is_file():
        raise CRAError("MANIFEST.json is absent")
    manifest = read_json(manifest_path)
    stored = manifest.get("manifest_content_fingerprint")
    material = copy.deepcopy(manifest)
    material.pop("manifest_content_fingerprint", None)
    if stored != digest_object(material, "MANIFEST"):
        raise CRAError("manifest content fingerprint mismatch")
    if manifest.get("packet_members") != [str(path) for path in PACKET_ALLOWLIST]:
        raise CRAError("manifest packet allowlist mismatch")
    expected_hashed_files = {str(path) for path in (SKILL_REL, SOURCE_REL, LEXICON_REL, SCRIPT_REL, VECTORS_REL)}
    if set(manifest.get("files", {})) != expected_hashed_files:
        raise CRAError("manifest hashed-file set mismatch")
    for rel, metadata in manifest.get("files", {}).items():
        path = root / rel
        if not path.is_file() or raw_sha256(path) != metadata.get("sha256") or path.stat().st_size != metadata.get("bytes"):
            raise CRAError(f"manifest file mismatch: {rel}")
    source = read_json(root / SOURCE_REL)
    source_report = validate_source(source)
    lexicon_report = validate_lexicon(read_json(root / LEXICON_REL))
    if manifest.get("architecture_fingerprint") != source_report["architecture_fingerprint"]:
        raise CRAError("manifest architecture fingerprint mismatch")
    if manifest.get("succession_fingerprint") != source_report["succession"]["fingerprint"]:
        raise CRAError("manifest succession fingerprint mismatch")
    if manifest.get("structural_lexicon") != lexicon_report:
        raise CRAError("manifest Structural Lexicon fingerprint mismatch")
    if manifest.get("readable_projection_fingerprint") != readable_projection_fingerprint(source):
        raise CRAError("manifest readable projection fingerprint mismatch")
    qualification = qualify(root, include_results=False)
    if qualification["status"] != "PASS" or manifest.get("qualification_fingerprint") != qualification["qualification_fingerprint"]:
        raise CRAError("manifest qualification fingerprint mismatch")
    if manifest.get("coverage") != qualification.get("coverage"):
        raise CRAError("manifest coverage summary mismatch")
    release_material = copy.deepcopy(manifest)
    release_material.pop("manifest_content_fingerprint", None)
    stored_release = release_material.pop("release_fingerprint", None)
    if stored_release != digest_object(release_material, "RELEASE"):
        raise CRAError("manifest release fingerprint mismatch")
    readable_mode = None
    if docx:
        if not docx.is_file():
            raise CRAError("external readable is absent")
        external = manifest.get("external_readable", {})
        byte_exact = raw_sha256(docx) == external.get("sha256") and docx.stat().st_size == external.get("bytes")
        with tempfile.TemporaryDirectory(prefix="cra-v1-1-readable-") as temporary_name:
            canonical_docx = Path(temporary_name) / external.get("name", "CRA_v1.1_Minimal_Readable.docx")
            render_docx(root, canonical_docx, qualification)
            issues = verify_docx_projection(source, docx, extract_docx_text(canonical_docx))
        if issues:
            raise CRAError(f"external readable projection mismatch: {issues}")
        if strict_docx_bytes and not byte_exact:
            raise CRAError("external readable mismatch")
        readable_mode = "BYTE_EXACT" if byte_exact else "CANONICAL_VISIBLE_TEXT"
    return {"status": "PASS", "release_fingerprint": manifest["release_fingerprint"], "readable_mode": readable_mode}


def release(root: Path, docx: Path, packet: Path) -> dict[str, Any]:
    qualification = qualify(root, include_results=False)
    if qualification["status"] != "PASS":
        raise CRAError("qualification failed: " + "; ".join(qualification["failures"]))
    render_docx(root, docx, qualification)
    source = read_json(root / SOURCE_REL)
    projection_issues = verify_docx_projection(source, docx)
    if projection_issues:
        raise CRAError(f"DOCX projection drift: {projection_issues}")
    manifest = build_manifest(root, docx, qualification)
    write_json(root / MANIFEST_REL, manifest)
    verify_manifest(root, docx)
    canonical_zip(root, packet)
    with tempfile.TemporaryDirectory(prefix="cra-v1-1-verify-") as temp_name:
        temp = Path(temp_name)
        with zipfile.ZipFile(packet) as archive:
            names = archive.namelist()
            expected = [f"CRA-v1.1/{rel.as_posix()}" for rel in PACKET_ALLOWLIST]
            if names != expected:
                raise CRAError(f"packet member/order drift: {names}")
            for member in archive.infolist():
                target = (temp / member.filename).resolve()
                if not str(target).startswith(str(temp.resolve()) + os.sep):
                    raise CRAError("archive traversal detected")
            archive.extractall(temp)
        extracted_root = temp / "CRA-v1.1"
        verify_manifest(extracted_root)
        extracted_qualification = qualify(extracted_root)
        if extracted_qualification["status"] != "PASS" or extracted_qualification["qualification_fingerprint"] != qualification["qualification_fingerprint"]:
            raise CRAError("re-extracted packet does not reproduce qualification")
    return {
        "status": "PASS",
        "docx": str(docx),
        "packet": str(packet),
        "docx_sha256": raw_sha256(docx),
        "packet_sha256": raw_sha256(packet),
        "release_fingerprint": manifest["release_fingerprint"],
        "qualification": qualification,
    }


def command_inspect(root: Path, operation: str | None = None) -> None:
    source = read_json(root / SOURCE_REL)
    report = validate_source(source)
    lexicon_report = validate_lexicon(read_json(root / LEXICON_REL))
    output: dict[str, Any] = {
        "release": source["release"],
        "core": source["core"],
        "roots": source["roots"],
        "laws": source["laws"],
        "outcomes": source["outcomes"],
        "operators": source["operators"],
        "profiles": source["profiles"],
        "boundaries": source["boundaries"],
        "finite_reference": source["reference_profile"],
        "counts": report,
        "structural_lexicon": lexicon_report,
    }
    if operation:
        starter_vectors = {
            "rebind": "V-001-REBIND",
            "contextualize": "V-036-CONTEXTUALIZE",
            "judge": "V-037-JUDGE",
            "apply": "V-038-APPLY",
            "admit": "V-039-ADMIT",
            "compose": "V-004-COMPOSE",
            "reassess": "V-005-REASSESS",
            "effect": "V-006-EFFECT",
            "projection": "V-007-PROJECTION",
            "carrier": "V-008-CARRIER",
        }
        fixtures, vectors = load_vector_model(root / VECTORS_REL)
        vector = next((row for row in vectors if row["id"] == starter_vectors[operation]), None)
        if vector is None:
            raise CRAError(f"starter vector is absent for {operation}")
        candidate = resolve_vector(vector, fixtures)
        evaluation = evaluate_case(candidate, source, root)
        if evaluation.outcome != "EARNED":
            raise CRAError(f"starter candidate no longer earns for {operation}")
        output["starter"] = {
            "operation": operation,
            "finite_profile_only": True,
            "input": candidate,
            "expected_value_type": (evaluation.value or {}).get("type"),
        }
    print(json.dumps(output, indent=2, ensure_ascii=False))


def command_lexicon(root: Path, term: str | None = None, category: str | None = None) -> None:
    lexicon = read_json(root / LEXICON_REL)
    report = validate_lexicon(lexicon)
    entries = lexicon["entries"]
    if category:
        entries = [row for row in entries if row["category"] == category]
    if term:
        needle = unicodedata.normalize("NFC", term).casefold()
        entries = [
            row for row in entries
            if needle in row["canonical_label"].casefold()
            or any(needle in alias.casefold() for alias in row["aliases"])
        ]
    print(json.dumps({
        "role": lexicon["role"],
        "authority": lexicon["authority"],
        "nonimplication": lexicon["nonimplication"],
        "report": report,
        "matches": len(entries),
        "entries": entries,
    }, indent=2, ensure_ascii=False))


def command_run(root: Path, input_path: Path) -> None:
    source = read_json(root / SOURCE_REL)
    validate_source(source)
    try:
        case = read_json(input_path)
        evaluation = evaluate_case(case, source, root)
    except (CRAError, ValueError, RecursionError) as exc:
        failure_outcomes = {row["id"]: row["outcome"] for row in source["failures"]}
        evaluation = Evaluation()
        evaluation.add(
            "F-INTEGRITY",
            f"input entry was refused before evaluation: {type(exc).__name__}",
            "B-OUTCOME",
            failure_outcomes,
        )
    print(json.dumps(evaluation.as_dict(), indent=2, ensure_ascii=False))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("inspect", "lexicon", "run", "verify", "qualify", "release"))
    parser.add_argument("--root")
    parser.add_argument("--input", type=Path)
    parser.add_argument("--docx", type=Path)
    parser.add_argument("--packet", type=Path)
    parser.add_argument(
        "--operation",
        choices=("rebind", "contextualize", "judge", "apply", "admit", "compose", "reassess", "effect", "projection", "carrier"),
    )
    parser.add_argument("--full", action="store_true")
    parser.add_argument("--term")
    parser.add_argument("--category")
    args = parser.parse_args()
    try:
        root = root_from_arg(args.root)
        if args.command == "inspect":
            command_inspect(root, args.operation)
        elif args.command == "lexicon":
            command_lexicon(root, args.term, args.category)
        elif args.command == "run":
            if not args.input:
                raise CRAError("run requires --input")
            command_run(root, args.input)
        elif args.command == "qualify":
            report = qualify(root, include_results=args.full)
            print(json.dumps(report, indent=2, ensure_ascii=False))
            if report["status"] != "PASS":
                return 1
        elif args.command == "verify":
            report = qualify(root, include_results=False)
            if report["status"] != "PASS":
                print(json.dumps(report, indent=2, ensure_ascii=False))
                return 1
            manifest_report = verify_manifest(root, args.docx.resolve() if args.docx else None, strict_docx_bytes=False)
            print(json.dumps({"status": "PASS", "qualification": report, "manifest": manifest_report}, indent=2, ensure_ascii=False))
        elif args.command == "release":
            if not args.docx or not args.packet:
                raise CRAError("release requires --docx and --packet")
            print(json.dumps(release(root, args.docx.resolve(), args.packet.resolve()), indent=2, ensure_ascii=False))
        return 0
    except (CRAError, OSError, ValueError, KeyError, TypeError, RecursionError, zipfile.BadZipFile) as exc:
        print(json.dumps({"status": "FAIL", "error": str(exc)}, indent=2), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
