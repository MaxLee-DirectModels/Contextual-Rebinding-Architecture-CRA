---
name: contextual-rebinding
description: Analyze, design, or audit passage of claims, evidence, obligations, authority, identity, state, or effects between changed contexts or autonomous regimes. Use for translations, projections, compressions, migrations, merges, succession, institutional admission, cross-model interoperability, provenance reconstruction, and any request asking what survives a boundary. Return only locally earned results; expose unsupported transport or missing proof as exact noncompletion. Do not use as a substitute for a domain theory, truth source, legal authority, security system, or transaction engine.
---

# Contextual Rebinding

Treat every result as indexed to the Regime, Demand, and Basis that earned it. Permit only typed material and declared guarantees across a boundary. Require destination Judgment and Standing to be earned locally.

## Load

1. Extract the packet and enter its `CRA-v1.1` root.
2. Run `python scripts/cra.py verify --root .` before first use in a session.
3. Run `python scripts/cra.py inspect --root .` for the constitution and finite-reference boundary.
4. Select the needed operator and exact profile×dimension cell. Use `inspect --operation OPERATOR` for a complete finite-profile starter, then read only its referenced sections in `references/cra.json`, the sole normative source.
5. For deep analysis, predecessor terminology, profile discovery, or a vocabulary sweep, query `references/structural_lexicon.json` through `lexicon --term TERM` or `lexicon --category CATEGORY`. It is a manifest-bound, nonnormative support index: matching a word never activates a root, guarantee, Judgment, Standing, authority, or profile.
6. Load the complete source, lexicon, or `tests/vectors.jsonl` only for full audit, qualification, reconstruction, or debugging.

If integrity verification fails, stop. Do not reconstruct missing rules from this file.

## Apply

1. Identify the source and destination Regimes. Do not presume shared meaning from matching words or bytes.
2. State the exact Demand: Return, use, protected conditions, horizon, and required Standing.
3. Build or request a Basis complete for that Demand and operator. Include semantic, justificatory, authority, obligation, temporal, and effect dependencies.
4. If crossing a Regime or index, require a typed Correspondence with a declared domain, guarantee, verifier, loss, error, residual, and validity boundary.
5. Account for source and produced destination occurrences as multisets. Require an executed relation-specific witness for every introduction, reusable copy, partition, merge, transformation, transfer, loss, or discharge. Equal values or self-declared witness labels are insufficient.
6. Use the destination Regime to Judge the local Claim and, if requested, Admit bounded Standing. Never transport Standing.
7. Return one outcome only: `EARNED`, `REJECTED`, or `OPEN`. For `OPEN`, preserve the returned `OpenCertificate`: first detected break, deepest independently verified prefix or `NONE_EARNED`, disclosed remaining obligations, localized Return components, reverse evidence, Standing ceiling, and earliest lawful reentry. Do not claim unexamined later obligations failed or that the fail-fast certificate discovered every open-world blocker.

## Output

Report:

- outcome and exact scope;
- Regime, Demand, Basis, operator, and selected profiles;
- transported material and guarantee bounds;
- loss, error, residuals, obligations, and assumptions;
- destination Judgment and Standing, if earned;
- effect status separately, if relevant;
- reverse trace from every authoritative result to its exact dependencies;
- explicit boundaries and lawful recovery ports.

For `OPEN`, reproduce the OpenCertificate's exact distinctions. A partial Context, Correspondence, CrossingAccount, Judgment, effect trace, projection comparison, or dependency delta may be reported only when its verifier completed and the certificate carries its artifact fingerprint. Never convert that partial result into requested Standing or Effect.

Do not call internal conformance truth, authenticity, legitimacy, causation, durability, atomicity, external value, or universal completeness.

## Commands

```bash
python scripts/cra.py inspect --root .
python scripts/cra.py inspect --operation rebind --root .
python scripts/cra.py lexicon --term standing --root .
python scripts/cra.py lexicon --category open-frontiers --root .
python scripts/cra.py run --input INPUT.json --root .
python scripts/cra.py verify --docx CRA_v1.1_Minimal_Readable.docx --root .
python scripts/cra.py qualify --root .
```

`run` accepts a complete candidate record for the bundled finite profile, not prose; begin with `starter.input` from `inspect --operation`. Use `qualify` only for the shipped finite reference models. A pass establishes the exact named cells and boundaries declared in `references/cra.json`; it does not promote specified-but-unexecuted fan-in, fan-out, diamond, cycle, nested passage, transaction, action, or external validation claims. `verify --docx` accepts either the exact released DOCX or an export with identical canonical visible text.
